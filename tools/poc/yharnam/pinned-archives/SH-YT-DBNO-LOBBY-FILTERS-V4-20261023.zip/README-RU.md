# Seamless Hunt × Yharnam Together — DBNO & Lobby Filters V4

**Версия:** 2026-10-23. **Статус:** проверенные standalone-компоненты, не игровая DLL и не обновление рабочего Fornex.

## Новое в V4

- **Down But Not Out (DBNO)** в настройках хоста. По умолчанию ВКЛ (наследуем механику Yharnam Together). При выключении отключается *предполагаемый сценарий* нокдауна/воскрешения, когда он будет подключён к игровому коду. Сам игровой runtime пока **не переключает** механику. Это пока серверное правило для будущей интеграции.
- Сервер отдаёт `down_but_not_out`, `invasions_enabled`, `scaling`, `settings_revision`, `free_slots` в списке комнат. Пароли, соли и токены игроков не выдаются публично.
- Общие правила фильтрации для **Lobby Browser** и **Quick Play**: `dbno` on/off/any, `invasion` on/off/any, `scaling` off/normal/hard/custom/any, регион, уровень, заполненность, количество доступных мест, показ начатых сессий. Приватные комнаты исключаются всегда.
- Изменение настроек только хостом (локальный demo API использует host_token), с `expected_revision` для защиты от устаревших изменений; во время начатой охоты переключение механик запрещено до следующей сессии, чтобы клиенты не расходились в трактовке смерти/нокдауна.
- C++20 `session_matchmaking.hpp`: `Rules.dbno_enabled`, `RoomFilters`, `RoomView`, `Browse`, фильтруемый `QuickPlay`, host-authorized `Configure` с номером ревизии, `StartHunt`. Защита от случайных вторжений в парольные комнаты остаётся.
- Предыдущая V3: отдельная тестовая логика P2P/relay, PvP-инвейды, UI Scale/роль invader, проверенные основы. **Переноса реальных игровых пакетов на P2P пока нет**.

## Демонстрационный JSON HTTP API (только loopback)

После `python3 matchmaking_http.py` на `127.0.0.1:32316`:

```http
POST /v1/rooms
Content-Type: application/json

{"host_id":"test-host","title":"Central Yharnam","protocol":7,"game_build":"pinned-yt","max_players":4,"down_but_not_out":true,"invasions_enabled":false,"scaling":"normal"}
```

В ответе возвращается `host_token` — храни его только у хоста и никогда не публикуй в браузере.

```http
GET /v1/rooms?protocol=7&game_build=pinned-yt&level=65&dbno=on&invasion=off&scaling=normal&hide_full=true&min_open_slots=2
```

Список включает только публичные подходящие комнаты, где есть два свободных места.

```http
POST /v1/quickplay
Content-Type: application/json

{"player_id":"hunter-test","protocol":7,"game_build":"pinned-yt","level":65,"dbno":true,"invasion":false,"scaling":"normal","min_open_slots":1}
```

При `GET /v1/rooms` допустимы `dbno=any|on|off`, `invasion=any|on|off`; `scaling=any|off|normal|hard|custom`; `hide_full=true|false`; `include_started=true|false`; `min_open_slots=0..4`. Чтобы показать полные комнаты, задайте **оба** `hide_full=false&min_open_slots=0`. На полные комнаты всё равно нельзя бронировать места.

```http
POST /v1/rooms/<room_id>/configure
X-Hunter-Token: <host_token>
Content-Type: application/json

{"down_but_not_out":false,"invasions_enabled":false,"scaling":"hard","expected_revision":1}
```

После настройки сервер увеличивает номер `settings_revision`. Старые номера ревизий отвергаются. При изменении правил ожидающие подтверждения брони мест сбрасываются. Начавшаяся охота блокирует изменение правил.

## Тесты

```bash
python3 -m unittest discover -s tests -v
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --parallel 4
ctest --test-dir build --output-on-failure
```

Проверено здесь: **31 Python-тест и 5 C++ тестов прошли**. Прототип HTTP API слушает только 127.0.0.1 и **не должен** быть доступен из интернета.

## Игровая интеграция ещё требуется

1. Новые флаги добавить в `server/coop/coop.proto`, реальный `TeamLobby`/`BloodborneWorld` и Qt WebAPI; все настройки применять через существующую аутентификацию shadNet. Сохранение в БД/восстановление после перезапуска требует отдельной реализации.
2. Добавить в **внутриигровой** `Team::Screen` Yharnam Together переключатель DBNO и страницы фильтров. Лаунчер не должен содержать механику комнат. После изменений компилировать Windows-native BBPort.
3. Подключить переключатель DBNO к `TickPartyDeath` и клиентским/серверным правилам воскрешения, с одинаковой настройкой для всех участников, в том числе вторженцев. Выкл = обычная смерть без revive. Вкл = действующая механика со стороной атакующего/защитника и проверкой оружейных ударов.
4. Для Quick Play группой использовать атомарную резервацию всей группы (имеется модель в C++); `matchmaking.py` как отдельный локальный PoC пока демонстрирует одиночное бронирование.
5. Настоящий Direct UDP P2P с подписанным peer-сигналингом и fallback пока не подключён. Расход CPU Fornex не снижен этим пакетом.
6. **Пять персонажей** в игре ещё не работают. Базовый Yharnam TeamSize=4, guest signs 7/6/5; никакой номер в интерфейсе этого не исправляет.

**Для текущего VPS никаких команд выполнять не надо.** Production CLS, тестовый Yharnam shadNet, DNS и firewall не изменялись.
