"""Seamless Hunt matchmaking domain PoC. No Bloodborne game/relay integration yet.

Only control-plane state, no UDP forwarding. Nothing here should be exposed
publicly until integrated with shadNet authentication and TLS/rate limiting.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from hashlib import pbkdf2_hmac, sha256
from hmac import compare_digest
import secrets
from threading import RLock
from time import monotonic
from typing import Callable

DEFAULT_SERVER = '199.195.193.131'
DEFAULT_CLIENT_PORTS = {'udp': 32314, 'webapi': 32315, 'backend': 21443}
MAX_SAFE_PLAYERS = 4  # Five requires changed/verified game member slots and protocol.


class LobbyError(Exception):
    pass


class NotAuthorized(LobbyError):
    pass


class NotFound(LobbyError):
    pass


class Full(LobbyError):
    pass


class Incompatible(LobbyError):
    pass


class Unsupported(LobbyError):
    pass


@dataclass
class Member:
    player_id: str
    token_digest: bytes
    joined_ms: int
    transport_capable: bool = False


@dataclass
class Reservation:
    player_id: str
    token_digest: bytes
    expires_ms: int


@dataclass
class Room:
    room_id: str
    host_id: str
    host_token_digest: bytes
    title: str
    protocol: int
    game_build: str
    max_players: int
    region: str
    is_private: bool
    password_salt: bytes | None
    password_digest: bytes | None
    invasions_enabled: bool
    dbno_enabled: bool
    scaling: str
    min_level: int
    max_level: int
    created_ms: int
    members: dict[str, Member] = field(default_factory=dict)
    reservations: dict[str, Reservation] = field(default_factory=dict)
    started: bool = False
    settings_revision: int = 1

    def occupancy(self) -> int:
        return len(self.members) + len(self.reservations)


class Matchmaker:
    def __init__(self, clock: Callable[[], int] | None = None, *, max_players: int = MAX_SAFE_PLAYERS):
        if not (2 <= max_players <= MAX_SAFE_PLAYERS):
            raise Unsupported('Five-player gameplay is not verified. Do not enable it on the live server.')
        self._clock = clock or (lambda: int(monotonic() * 1000))
        self._capacity = max_players
        self._rooms: dict[str, Room] = {}
        self._lock = RLock()

    @staticmethod
    def _digest(token: str) -> bytes:
        return sha256(token.encode('utf-8')).digest()

    @staticmethod
    def _random() -> str:
        return secrets.token_urlsafe(24)

    @staticmethod
    def _password(password: str, salt: bytes) -> bytes:
        return pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 120_000)

    @staticmethod
    def _validate_player(player_id: str):
        if not isinstance(player_id, str) or not 3 <= len(player_id) <= 64:
            raise LobbyError('invalid player id')

    @staticmethod
    def _validate_settings(max_players: int, capacity: int, min_level: int, max_level: int,
                           scaling: str, region: str):
        if not isinstance(max_players, int) or not 2 <= max_players <= capacity:
            raise Unsupported('the runtime currently supports at most four players')
        if not isinstance(min_level, int) or not isinstance(max_level, int) or not 1 <= min_level <= max_level <= 544:
            raise LobbyError('invalid blood-level range')
        if scaling not in ('off', 'normal', 'hard', 'custom'):
            raise LobbyError('unsupported scaling mode')
        if region not in ('any', 'eu', 'us', 'jp', 'asia'):
            raise LobbyError('invalid region')

    def _clean(self, room: Room):
        now = self._clock()
        for player_id, res in list(room.reservations.items()):
            if res.expires_ms <= now:
                del room.reservations[player_id]

    @staticmethod
    def _listing(room: Room) -> dict:
        return {'room_id': room.room_id, 'title': room.title,
                'players': len(room.members), 'reserved': len(room.reservations),
                'max_players': room.max_players, 'region': room.region,
                'invasions_enabled': room.invasions_enabled,
                'down_but_not_out': room.dbno_enabled,
                'scaling': room.scaling,
                'settings_revision': room.settings_revision,
                'free_slots': max(0, room.max_players - room.occupancy()),
                'password_protected': room.is_private, 'min_level': room.min_level,
                'max_level': room.max_level, 'started': room.started,
                'transport': 'direct-capable' if all(m.transport_capable for m in room.members.values()) else 'relay-fallback',
                'game_build': room.game_build, 'protocol': room.protocol}

    def create(self, *, host_id: str, title: str, protocol: int, game_build: str,
               max_players: int = 4, region: str = 'any', password: str = '',
               invasions_enabled: bool = False, down_but_not_out: bool = True, scaling: str = 'normal',
               min_level: int = 1, max_level: int = 544) -> dict:
        self._validate_player(host_id)
        self._validate_settings(max_players, self._capacity, min_level, max_level, scaling, region)
        if not isinstance(protocol, int) or protocol < 1 or not isinstance(game_build, str) or not game_build.strip():
            raise LobbyError('protocol and build are required')
        if not isinstance(title, str) or not 1 <= len(title.strip()) <= 64:
            raise LobbyError('invalid room title')
        if not isinstance(password, str) or len(password) > 128:
            raise LobbyError('invalid password')
        if type(invasions_enabled) is not bool or type(down_but_not_out) is not bool:
            raise LobbyError('boolean mechanics settings required')
        salt = secrets.token_bytes(16) if password else None
        pwd_hash = self._password(password, salt) if salt else None
        room_id, host_token = self._random(), self._random()
        now = self._clock()
        room = Room(room_id, host_id, self._digest(host_token), title.strip(), protocol,
                    game_build, max_players, region, bool(password), salt, pwd_hash,
                    invasions_enabled, down_but_not_out, scaling, min_level, max_level, now)
        room.members[host_id] = Member(host_id, self._digest(host_token), now)
        with self._lock:
            self._rooms[room_id] = room
        return {'room': self._listing(room), 'host_token': host_token}

    def browse(self, *, protocol: int, game_build: str, region: str = 'any',
               level: int = 1, invasion: bool | None = None,
               dbno: bool | None = None, scaling: str | None = None,
               hide_full: bool = True, min_open_slots: int = 1,
               include_started: bool = False, limit: int = 100) -> list[dict]:
        if not isinstance(limit, int) or not 1 <= limit <= 100:
            raise LobbyError('invalid page size')
        if type(hide_full) is not bool or type(include_started) is not bool:
            raise LobbyError('boolean room filters required')
        if any(value is not None and type(value) is not bool for value in (invasion, dbno)):
            raise LobbyError('mechanic filter must be any, on or off')
        if scaling is not None and scaling not in ('off', 'normal', 'hard', 'custom'):
            raise LobbyError('unsupported scaling filter')
        if type(min_open_slots) is not int or not 0 <= min_open_slots <= 4:
            raise LobbyError('invalid minimum free slots')
        with self._lock:
            output = []
            for room in self._rooms.values():
                self._clean(room)
                if room.is_private or room.protocol != protocol or room.game_build != game_build:
                    continue
                if room.region != 'any' and region != 'any' and room.region != region:
                    continue
                if not room.min_level <= level <= room.max_level:
                    continue
                if invasion is not None and room.invasions_enabled != invasion:
                    continue
                if dbno is not None and room.dbno_enabled != dbno:
                    continue
                if scaling is not None and room.scaling != scaling:
                    continue
                if (hide_full and room.occupancy() >= room.max_players) or (room.started and not include_started):
                    continue
                if room.max_players - room.occupancy() < min_open_slots:
                    continue
                output.append(self._listing(room))
            return sorted(output, key=lambda row: (row['players'], row['room_id']), reverse=True)[:limit]

    def reserve(self, room_id: str, *, player_id: str, protocol: int, game_build: str,
                level: int, password: str = '', ttl_ms: int = 20_000) -> dict:
        self._validate_player(player_id)
        if not 1000 <= ttl_ms <= 120_000:
            raise LobbyError('invalid reservation TTL')
        with self._lock:
            room = self._rooms.get(room_id)
            if room is None:
                raise NotFound('room unavailable')
            self._clean(room)
            if room.protocol != protocol or room.game_build != game_build:
                raise Incompatible('game protocol/build mismatch')
            if not room.min_level <= level <= room.max_level:
                raise Incompatible('blood level out of room range')
            if room.password_digest is not None:
                if not compare_digest(self._password(password, room.password_salt), room.password_digest):
                    raise NotAuthorized('incorrect room password')
            if player_id in room.members or player_id in room.reservations:
                raise LobbyError('player already in room or pending')
            if room.occupancy() >= room.max_players:
                raise Full('all room slots are occupied')
            token = self._random()
            room.reservations[player_id] = Reservation(player_id, self._digest(token), self._clock() + ttl_ms)
            return {'room_id': room_id, 'reservation_token': token, 'expires_ms': self._clock() + ttl_ms}

    def quickplay(self, *, player_id: str, protocol: int, game_build: str,
                  level: int, region: str = 'any', invasion: bool | None = None,
                  dbno: bool | None = None, scaling: str | None = None,
                  hide_full: bool = True, min_open_slots: int = 1,
                  include_started: bool = False) -> dict | None:
        with self._lock:
            rooms = self.browse(protocol=protocol, game_build=game_build,
                                level=level, region=region, invasion=invasion,
                                dbno=dbno, scaling=scaling, hide_full=hide_full,
                                min_open_slots=max(min_open_slots, 1), include_started=include_started)
            for room in rooms:
                try:
                    return self.reserve(room['room_id'], player_id=player_id,
                                        protocol=protocol, game_build=game_build, level=level)
                except (Full, NotFound, LobbyError):
                    pass
            return None

    def confirm(self, room_id: str, *, player_id: str, reservation_token: str) -> dict:
        with self._lock:
            room = self._rooms.get(room_id)
            if room is None:
                raise NotFound('room unavailable')
            self._clean(room)
            pending = room.reservations.get(player_id)
            if pending is None or not compare_digest(pending.token_digest, self._digest(reservation_token)):
                raise NotAuthorized('invalid or expired reservation')
            del room.reservations[player_id]
            room.members[player_id] = Member(player_id, pending.token_digest, self._clock())
            return self._listing(room)

    def configure(self, room_id: str, *, host_token: str, invasions_enabled: bool | None = None,
                  down_but_not_out: bool | None = None, scaling: str | None = None,
                  started: bool | None = None, expected_revision: int | None = None) -> dict:
        with self._lock:
            room = self._rooms.get(room_id)
            if room is None:
                raise NotFound('room unavailable')
            if not compare_digest(room.host_token_digest, self._digest(host_token)):
                raise NotAuthorized('only the host can change room settings')
            if expected_revision is not None and expected_revision != room.settings_revision:
                raise Incompatible('host settings were updated by another action')
            if any(value is not None and type(value) is not bool
                   for value in (invasions_enabled, down_but_not_out, started)):
                raise LobbyError('boolean mechanics settings required')
            if scaling is not None and scaling not in ('off', 'normal', 'hard', 'custom'):
                raise LobbyError('unsupported scaling')
            change = ((scaling is not None and scaling != room.scaling) or
                      (invasions_enabled is not None and invasions_enabled != room.invasions_enabled) or
                      (down_but_not_out is not None and down_but_not_out != room.dbno_enabled))
            # Prevent mid-combat changes from rewriting how downed players are handled.
            if room.started and change:
                raise Unsupported('gameplay rules are locked while the hunt is active')
            if started is False and room.started:
                raise Unsupported('cannot reset a live session through room settings')
            if scaling is not None:
                room.scaling = scaling
            if invasions_enabled is not None:
                room.invasions_enabled = invasions_enabled
            if down_but_not_out is not None:
                room.dbno_enabled = down_but_not_out
            if started is not None:
                room.started = started
            if change:
                # A reservation was issued under the previous gameplay rules.
                # Invalidate it so a late confirmation cannot silently change DBNO semantics.
                room.reservations.clear()
            if change or started is not None:
                room.settings_revision += 1
            return self._listing(room)

    def transport_plan(self, room_id: str, *, player_id: str, token: str,
                       direct_capable: bool) -> dict:
        """Control-plane hints ONLY; not P2P hole punching or game packet delivery."""
        with self._lock:
            room = self._rooms.get(room_id)
            if room is None:
                raise NotFound('room unavailable')
            member = room.members.get(player_id)
            if member is None or not compare_digest(member.token_digest, self._digest(token)):
                raise NotAuthorized('member login required')
            member.transport_capable = bool(direct_capable)
            return {'mode': 'p2p-attempt-then-relay', 'fallback': 'relay',
                    'members': len(room.members), 'room_id': room.room_id,
                    'note': 'signaling and game UDP migration not implemented; existing server relay remains active'}

    def close(self, room_id: str, *, host_token: str):
        with self._lock:
            room = self._rooms.get(room_id)
            if room is None:
                raise NotFound('room unavailable')
            if not compare_digest(room.host_token_digest, self._digest(host_token)):
                raise NotAuthorized('host authorization required')
            del self._rooms[room_id]
