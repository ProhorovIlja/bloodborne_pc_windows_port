// SPDX-License-Identifier: GPL-2.0-or-later
// Seamless Hunt: policy core for FUTURE in-game matchmaking.
// Not wired to live shadNet, the game's P2P stream, or PvP combat yet.
#pragma once
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <map>
#include <mutex>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace SeamlessHunt::InGame {
enum class Mode { Coop, Invasion };
enum class Visibility { Public, Private };
enum class Scaling { Vanilla, PartyBalanced, Challenging };
enum class RoutePreference { DirectP2P, RelayOnly };
enum class Reject { None, Closed, Private, InvasionsDisabled, InvasionCap, Full, InvalidGroup, MismatchedBuild, LevelMismatch, DuplicatePlayer, AlreadyReserved };

struct Hunter {
    std::string id;
    int level = 4;
};
struct Party {
    std::string id;
    std::vector<Hunter> members;
};
struct Rules {
    Visibility visibility = Visibility::Public;
    Scaling scaling = Scaling::PartyBalanced;
    RoutePreference route = RoutePreference::DirectP2P;
    bool invasions_enabled = false;
    bool dbno_enabled = true; // Down But Not Out, host-controlled; default matches existing YT.
    bool password_protected = false; // no random invasion or Quick Play in a passworded room
    unsigned total_slots = 4;   // current client has 4 slots; 5 must pass runtime certification
    unsigned invasion_slots = 0;
    int level_tolerance = 40;
};
struct Room {
    std::string id;
    std::string game_build;
    std::string title, region="any";
    Rules rules;
    std::vector<Party> defenders;
    std::vector<Party> invaders;
    bool open = true;
    bool started = false;
    std::uint64_t rules_revision = 1;
};
struct Admission {
    Reject reject = Reject::None;
    unsigned free_slots = 0;
    explicit operator bool() const { return reject == Reject::None; }
};
inline unsigned Count(const std::vector<Party>& ps) {
    unsigned n = 0;
    for (const Party& p : ps) n += static_cast<unsigned>(p.members.size());
    return n;
}
inline unsigned Players(const Room& r) { return Count(r.defenders) + Count(r.invaders); }
inline int HostLevel(const Room& r) {
    return r.defenders.empty() || r.defenders.front().members.empty() ? 0 : r.defenders.front().members.front().level;
}
inline bool UniqueMembers(const Party& group) {
    if (group.id.empty() || group.members.empty()) return false;
    std::set<std::string> ids;
    for (const auto& p : group.members) {
        if (p.id.empty() || p.level < 4 || p.level > 544 || !ids.insert(p.id).second) return false;
    }
    return true;
}
inline Admission CanJoin(const Room& r, const Party& group, Mode mode, std::string_view client_build,
                         bool server_authorized_private, unsigned reserved = 0,
                         unsigned reserved_invaders = 0, bool five_slot_runtime_certified = false) {
    const unsigned hard_limit = five_slot_runtime_certified ? 5u : 4u;
    if (!r.open) return {Reject::Closed};
    if (!UniqueMembers(group)) return {Reject::InvalidGroup};
    if (r.game_build.empty() || r.game_build != client_build) return {Reject::MismatchedBuild};
    if ((r.rules.visibility == Visibility::Private || r.rules.password_protected) &&
        !server_authorized_private) return {Reject::Private};
    // Invasion is never allowed into password-protected/private sessions, even with a valid invite.
    if (mode == Mode::Invasion &&
        (r.rules.visibility == Visibility::Private || r.rules.password_protected)) return {Reject::Private};
    if (r.defenders.empty() || !UniqueMembers(r.defenders.front())) return {Reject::InvalidGroup};
    for (const Party* p : [&] {
             std::vector<const Party*> all;
             for (const auto& q : r.defenders) all.push_back(&q);
             for (const auto& q : r.invaders) all.push_back(&q);
             return all;
         }()) {
        if (group.id == p->id) return {Reject::DuplicatePlayer};
        for (const auto& member : group.members)
            for (const auto& present : p->members)
                if (member.id == present.id) return {Reject::DuplicatePlayer};
    }
    if (mode == Mode::Invasion && !r.rules.invasions_enabled) return {Reject::InvasionsDisabled};
    if (mode == Mode::Invasion && Count(r.invaders) + reserved_invaders + group.members.size() > r.rules.invasion_slots)
        return {Reject::InvasionCap};
    if (Players(r) + reserved + group.members.size() > std::min(r.rules.total_slots, hard_limit))
        return {Reject::Full};
    if (std::any_of(group.members.begin(), group.members.end(), [&](const Hunter& h) {
            return std::abs(h.level - HostLevel(r)) > r.rules.level_tolerance;
        })) return {Reject::LevelMismatch};
    return {Reject::None, std::min(r.rules.total_slots, hard_limit) - Players(r) - reserved -
                              static_cast<unsigned>(group.members.size())};
}

// Unambiguous filters shared by in-game browser and Quick Play (nullopt == Any).
// Show Full is for viewing only; full rooms must never admit a connection.
struct RoomFilters {
    std::optional<bool> dbno, invasions;
    std::optional<Scaling> scaling;
    std::optional<RoutePreference> route;
    std::string region = "any";
    unsigned min_free_slots = 1;
    bool hide_full = true;
    bool include_started = false;
};
struct RoomView {
    std::string id, title, region;
    unsigned players=0, reserved=0, max_players=0, free_slots=0;
    bool dbno_enabled=false, invasions_enabled=false, started=false, joinable=false;
    Scaling scaling=Scaling::PartyBalanced;
    RoutePreference route=RoutePreference::DirectP2P;
    std::uint64_t rules_revision=0;
    Reject reason=Reject::None;
};
inline bool MatchesFilters(const Room& r,const RoomFilters& f) {
    if(!r.open||r.rules.visibility!=Visibility::Public||r.rules.password_protected)return false;
    if(r.started&&!f.include_started)return false;
    if(f.dbno&&r.rules.dbno_enabled!=*f.dbno)return false;
    if(f.invasions&&r.rules.invasions_enabled!=*f.invasions)return false;
    if(f.scaling&&r.rules.scaling!=*f.scaling)return false;
    if(f.route&&r.rules.route!=*f.route)return false;
    if(!f.region.empty()&&f.region!="any"&&r.region!="any"&&r.region!=f.region)return false;
    return true;
}
// Server-side, per-room atomic capacity reservations. These are ephemeral; persist real rooms/credentials elsewhere.
// Caller MUST authenticate player IDs and private-room authorization separately, never trust a client boolean.
class Matchmaker {
public:
    using Clock = std::chrono::steady_clock;
    using Time = Clock::time_point;
    struct Ticket { std::string id; std::string room_id; Mode mode; Party party; Time until; };
    explicit Matchmaker(bool five_slot_runtime_certified = false) : certified_(five_slot_runtime_certified) {}
    bool Create(Room room) {
        if (room.id.empty() || room.game_build.empty() || room.defenders.size() != 1 ||
            !UniqueMembers(room.defenders.front()) || room.rules.total_slots < Players(room) ||
            room.rules.total_slots > (certified_ ? 5u : 4u) || room.rules.invasion_slots > room.rules.total_slots ||
            room.rules.level_tolerance < 0 || room.rules.level_tolerance > 544 || !room.invaders.empty()) return false;
        std::scoped_lock lock(mu_);
        return rooms_.emplace(room.id, std::move(room)).second;
    }
    std::optional<std::string> QuickPlay(const Party& party, Mode mode, std::string_view build,
                                         Time now, const RoomFilters& filters = {}) {
        std::scoped_lock lock(mu_);
        Expire(now);
        for (auto& [id, room] : rooms_) {
            if (!MatchesFilters(room, filters)) continue;
            const auto [taken, hostile] = Reserved(id);
            const unsigned free=room.rules.total_slots>Players(room)+taken ?
                                room.rules.total_slots-Players(room)-taken:0;
            if (free < filters.min_free_slots || (filters.hide_full&&free==0))continue;
            if (CanJoin(room, party, mode, build, false, taken, hostile, certified_)) return id;
        }
        return std::nullopt;
    }
    // Public read-only cards: no room passwords or member tokens ever leave the server.
    std::vector<RoomView> Browse(const Party& party, Mode mode, std::string_view build, Time now,
                                  const RoomFilters& filters = {}) {
        std::scoped_lock lock(mu_);
        Expire(now);
        std::vector<RoomView> out;
        for(const auto& [id,room]:rooms_) {
            if(!MatchesFilters(room,filters)||room.game_build!=build)continue;
            const auto [reserved,hostile]=Reserved(id);
            const unsigned cap=std::min(room.rules.total_slots,certified_?5u:4u);
            const unsigned free=Players(room)+reserved>=cap?0:cap-Players(room)-reserved;
            if((filters.hide_full&&free==0)||free<filters.min_free_slots)continue;
            const auto admit=CanJoin(room,party,mode,build,false,reserved,hostile,certified_);
            if(!admit && !(admit.reject==Reject::Full&&!filters.hide_full))continue;
            out.push_back(RoomView{id,room.title,room.region,Players(room),reserved,cap,free,
                room.rules.dbno_enabled,room.rules.invasions_enabled,room.started,
                static_cast<bool>(admit),room.rules.scaling,room.rules.route,
                room.rules_revision,admit.reject});
        }
        std::stable_sort(out.begin(),out.end(),[](const RoomView& a,const RoomView& b){
            if(a.joinable!=b.joinable)return a.joinable>b.joinable;
            if(a.players!=b.players)return a.players>b.players;
            return a.id<b.id;
        });
        return out;
    }
    // Caller must have verified the actual shadNet account, not a self-reported host id.
    bool Configure(const std::string& id,const std::string& authenticated_host,
                   const Rules& updated,std::uint64_t expected_revision) {
        std::scoped_lock lock(mu_);
        auto it=rooms_.find(id);
        if(it==rooms_.end()||it->second.started||it->second.defenders.empty()||
           it->second.defenders.front().members.empty()||
           it->second.defenders.front().members.front().id!=authenticated_host||
           it->second.rules_revision!=expected_revision)return false;
        if(updated.total_slots<Players(it->second)||updated.total_slots>(certified_?5u:4u)||
           updated.invasion_slots>updated.total_slots||updated.level_tolerance<0||
           updated.level_tolerance>544)return false;
        it->second.rules=updated;
        ++it->second.rules_revision;
        // Reservations created under obsolete settings are invalidated atomically.
        for(auto t=tickets_.begin();t!=tickets_.end();)if(t->second.room_id==id)t=tickets_.erase(t);
             else ++t;
        return true;
    }
    bool StartHunt(const std::string& id,const std::string& authenticated_host) {
        std::scoped_lock lock(mu_);
        auto it=rooms_.find(id);
        if(it==rooms_.end()||it->second.defenders.empty()||
           it->second.defenders.front().members.empty()||
           it->second.defenders.front().members.front().id!=authenticated_host||
           it->second.started)return false;
        it->second.started=true;
        ++it->second.rules_revision;
        return true;
    }
    std::optional<Ticket> Reserve(std::string room_id, Party party, Mode mode,
                                  std::string_view build, bool server_authorized_private,
                                  Time now, std::chrono::seconds ttl = std::chrono::seconds{20}) {
        std::scoped_lock lock(mu_);
        Expire(now);
        if (ttl <= std::chrono::seconds{0} || ttl > std::chrono::seconds{60}) return std::nullopt;
        const auto found = rooms_.find(room_id);
        if (found == rooms_.end()) return std::nullopt;
        for (const auto& [id, t] : tickets_)
            for (const auto& h : party.members)
                for (const auto& reserved : t.party.members)
                    if (h.id == reserved.id) return std::nullopt;
        const auto [taken, hostile] = Reserved(room_id);
        if (!CanJoin(found->second, party, mode, build, server_authorized_private, taken, hostile, certified_))
            return std::nullopt;
        const Ticket ticket{std::to_string(++next_id_), std::move(room_id), mode, std::move(party), now + ttl};
        tickets_.emplace(ticket.id, ticket);
        return ticket;
    }
    bool Confirm(std::string_view ticket_id, Time now) {
        std::scoped_lock lock(mu_);
        Expire(now);
        const auto t = tickets_.find(std::string(ticket_id));
        if (t == tickets_.end()) return false;
        auto room = rooms_.find(t->second.room_id);
        if (room == rooms_.end() || !room->second.open) { tickets_.erase(t); return false; }
        // Recheck under the same mutex. The ticket itself already owns its capacity.
        if (t->second.mode == Mode::Invasion) room->second.invaders.push_back(t->second.party);
        else room->second.defenders.push_back(t->second.party);
        tickets_.erase(t);
        return true;
    }
    bool Close(std::string_view room_id) {
        std::scoped_lock lock(mu_);
        auto it = rooms_.find(std::string(room_id));
        if (it == rooms_.end()) return false;
        it->second.open = false;
        for (auto t = tickets_.begin(); t != tickets_.end();)
            if (t->second.room_id == room_id) t = tickets_.erase(t); else ++t;
        return true;
    }
    std::optional<Room> Snapshot(std::string_view room_id) const {
        std::scoped_lock lock(mu_);
        const auto it = rooms_.find(std::string(room_id));
        return it == rooms_.end() ? std::nullopt : std::optional<Room>{it->second};
    }
private:
    std::pair<unsigned,unsigned> Reserved(const std::string& room) const {
        unsigned all = 0, hostile = 0;
        for (const auto& [id,t] : tickets_) if (t.room_id == room) {
            const auto n = static_cast<unsigned>(t.party.members.size());
            all += n;
            if (t.mode == Mode::Invasion) hostile += n;
        }
        return {all, hostile};
    }
    void Expire(Time now) {
        for (auto it = tickets_.begin(); it != tickets_.end();)
            if (now >= it->second.until) it = tickets_.erase(it); else ++it;
    }
    bool certified_ = false;
    mutable std::mutex mu_;
    std::map<std::string,Room> rooms_;
    std::map<std::string,Ticket> tickets_;
    std::uint64_t next_id_ = 0;
};
} // namespace SeamlessHunt::InGame
