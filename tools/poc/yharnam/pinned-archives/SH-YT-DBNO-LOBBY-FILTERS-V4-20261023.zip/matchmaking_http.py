"""LOOPBACK-ONLY demonstration HTTP API; not connected to shadNet authentication.

Do not reverse-proxy or open to the Internet. For eventual public deployment,
replace this with authenticated Qt shadNet routes plus rate limiting and TLS.
"""
from __future__ import annotations
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs
import json
import re
from matchmaking import Matchmaker, LobbyError, NotFound, NotAuthorized, Full, Incompatible, Unsupported

MAX_BODY = 4096
ROOM_PATH = re.compile(r'^/v1/rooms/([A-Za-z0-9_-]{20,80})(?:/(reserve|confirm|configure|transport))?$')


def handler_factory(matchmaker: Matchmaker):
    class Handler(BaseHTTPRequestHandler):
        server_version = 'SeamlessHunt-ControlPoC/0.1'
        def log_message(self, fmt, *args):
            # Avoid accidentally logging passwords/tokens in request bodies or query.
            pass

        def _json(self, status: int, payload: dict | list):
            body = json.dumps(payload, separators=(',', ':')).encode('utf-8')
            self.send_response(status)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Cache-Control', 'no-store')
            self.send_header('Content-Length', str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def _data(self):
            raw_len = self.headers.get('Content-Length')
            if raw_len is None or not raw_len.isdecimal():
                raise LobbyError('JSON content length required')
            size = int(raw_len)
            if not 1 <= size <= MAX_BODY:
                raise LobbyError('JSON body too large or empty')
            data = json.loads(self.rfile.read(size))
            if not isinstance(data, dict):
                raise LobbyError('object expected')
            return data

        def _call(self, method):
            try:
                parts = urlsplit(self.path)
                path = parts.path
                if method == 'GET' and path == '/health':
                    return self._json(200, {'ok': True, 'service':'seamless-hunt-lobby-poc',
                                             'live_game_integration': False,
                                             'game_data_p2p': False})
                if method == 'GET' and path == '/v1/rooms':
                    q = parse_qs(parts.query)
                    def tri(name):
                        raw=q.get(name,['any'])[0].lower()
                        if raw in ('any',''): return None
                        if raw in ('true','on','1'): return True
                        if raw in ('false','off','0'): return False
                        raise LobbyError('invalid '+name+' filter')
                    def boolean(name, default):
                        raw=q.get(name,[str(default).lower()])[0].lower()
                        if raw in ('true','on','1'): return True
                        if raw in ('false','off','0'): return False
                        raise LobbyError('invalid '+name+' filter')
                    req = {'protocol':int(q['protocol'][0]),'game_build':q['game_build'][0],
                           'level':int(q.get('level',['1'])[0]),'region':q.get('region',['any'])[0],
                           'invasion':tri('invasion'),'dbno':tri('dbno'),
                           'scaling':None if q.get('scaling',['any'])[0]=='any' else q['scaling'][0],
                           'hide_full':boolean('hide_full',True),
                           'include_started':boolean('include_started',False),
                           'min_open_slots':int(q.get('min_open_slots',['1'])[0])}
                    return self._json(200, {'rooms':matchmaker.browse(**req)})
                if method == 'POST' and path == '/v1/rooms':
                    return self._json(201, matchmaker.create(**self._data()))
                if method == 'POST' and path == '/v1/quickplay':
                    reservation = matchmaker.quickplay(**self._data())
                    return self._json(200 if reservation else 404,
                                      reservation or {'error':'no-compatible-public-room'})
                room_match = ROOM_PATH.fullmatch(path)
                if room_match:
                    room_id, action = room_match.groups()
                    if method == 'DELETE' and action is None:
                        token = self.headers.get('X-Hunter-Token', '')
                        matchmaker.close(room_id, host_token=token)
                        return self._json(200, {'closed': True})
                    if method == 'POST':
                        data = self._data()
                        if action == 'reserve':
                            return self._json(201, matchmaker.reserve(room_id, **data))
                        if action == 'confirm':
                            return self._json(200, matchmaker.confirm(room_id, **data))
                        if action == 'configure':
                            token = self.headers.get('X-Hunter-Token', '')
                            return self._json(200, matchmaker.configure(room_id, host_token=token, **data))
                        if action == 'transport':
                            token = self.headers.get('X-Hunter-Token', '')
                            return self._json(200, matchmaker.transport_plan(room_id, token=token, **data))
                return self._json(404, {'error':'not-found'})
            except (ValueError, KeyError, TypeError, json.JSONDecodeError, LobbyError) as exc:
                if isinstance(exc, NotFound): status = 404
                elif isinstance(exc, NotAuthorized): status = 403
                elif isinstance(exc, (Full, Incompatible, Unsupported)): status = 409
                else: status = 400
                return self._json(status, {'error':type(exc).__name__.lower(), 'message': str(exc)[:160]})

        def do_GET(self): self._call('GET')
        def do_POST(self): self._call('POST')
        def do_DELETE(self): self._call('DELETE')

    return Handler


def main():
    # Restricted to loopback deliberately. Never bind 0.0.0.0 on a VPS.
    with ThreadingHTTPServer(('127.0.0.1', 32316), handler_factory(Matchmaker())) as server:
        print('SH matchmaking proof-of-concept control API: 127.0.0.1:32316 (localhost only)', flush=True)
        server.serve_forever(poll_interval=1)

if __name__ == '__main__': main()
