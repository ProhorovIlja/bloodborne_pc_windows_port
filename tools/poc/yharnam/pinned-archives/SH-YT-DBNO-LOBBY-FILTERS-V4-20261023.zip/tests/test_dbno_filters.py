import sys
import unittest
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
from urllib.error import HTTPError
from http.server import ThreadingHTTPServer
from threading import Thread
import json
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from matchmaking import Matchmaker, NotAuthorized, Incompatible, Unsupported, LobbyError
from matchmaking_http import handler_factory

class DbnoAndFiltersTests(unittest.TestCase):
    def setUp(self):
        self.mm=Matchmaker(clock=lambda:100_000)
        self.rooms={}
    def make(self,name,**kwargs):
        x=self.mm.create(host_id='host-'+name,title=name,protocol=7,game_build='native-yt-pin',**kwargs)
        self.rooms[name]=x
        return x
    def browse(self,**kwargs):
        return [x['title'] for x in self.mm.browse(protocol=7,game_build='native-yt-pin',level=65,**kwargs)]
    def test_dbno_default_on_and_listing_visible(self):
        self.make('default')
        row=self.mm.browse(protocol=7,game_build='native-yt-pin',level=65)[0]
        self.assertTrue(row['down_but_not_out'])
        self.assertEqual(row['free_slots'],3)
        self.assertEqual(row['settings_revision'],1)
        self.assertNotIn('host_token',row)
        self.assertNotIn('password_digest',row)
    def test_filters_tristate_and_scaling(self):
        self.make('on',down_but_not_out=True,invasions_enabled=True,scaling='hard')
        self.make('off',down_but_not_out=False,invasions_enabled=False,scaling='normal')
        self.assertEqual(set(self.browse()),{'on','off'})
        self.assertEqual(self.browse(dbno=True),['on'])
        self.assertEqual(self.browse(dbno=False),['off'])
        self.assertEqual(self.browse(invasion=True),['on'])
        self.assertEqual(self.browse(invasion=False),['off'])
        self.assertEqual(self.browse(dbno=False,invasion=True),[])
        self.assertEqual(self.browse(dbno=True,scaling='hard'),['on'])
    def test_quickplay_respects_same_filters(self):
        on=self.make('on',down_but_not_out=True,invasions_enabled=True,scaling='hard')
        off=self.make('off',down_but_not_out=False,invasions_enabled=False,scaling='normal')
        x=self.mm.quickplay(player_id='client',protocol=7,game_build='native-yt-pin',level=65,
                            dbno=False,invasion=False,scaling='normal')
        self.assertEqual(x['room_id'],off['room']['room_id'])
        self.assertIsNone(self.mm.quickplay(player_id='test',protocol=7,game_build='native-yt-pin',level=65,
                              dbno=True,invasion=False,scaling='normal'))
        y=self.mm.quickplay(player_id='test2',protocol=7,game_build='native-yt-pin',level=65,
                            dbno=True,invasion=True,scaling='hard')
        self.assertEqual(y['room_id'],on['room']['room_id'])
    def test_show_full_rooms_but_quickplay_wont_join_them(self):
        full=self.make('full',max_players=2)
        res=self.mm.reserve(full['room']['room_id'],player_id='next',protocol=7,game_build='native-yt-pin',level=65)
        self.mm.confirm(full['room']['room_id'],player_id='next',reservation_token=res['reservation_token'])
        self.assertEqual(self.browse(),[])
        self.assertEqual(self.browse(hide_full=False,min_open_slots=0),['full'])
        self.assertEqual(self.browse(hide_full=False,min_open_slots=1),[])
        self.assertIsNone(self.mm.quickplay(player_id='waiting',protocol=7,game_build='native-yt-pin',level=65,
                                             hide_full=False,min_open_slots=0))
    def test_group_size_minimum_open_slots(self):
        a=self.make('two',max_players=4)
        self.assertEqual(self.browse(min_open_slots=3),['two'])
        self.assertEqual(self.browse(min_open_slots=4),[])
        res=self.mm.reserve(a['room']['room_id'],player_id='next',protocol=7,game_build='native-yt-pin',level=65)
        self.assertEqual(self.browse(min_open_slots=2),['two'])
        self.assertEqual(self.browse(min_open_slots=3),[])
    def test_host_can_toggle_dbno_until_hunt_starts(self):
        a=self.make('settings')
        rid=a['room']['room_id']
        with self.assertRaises(NotAuthorized): self.mm.configure(rid,host_token='wrong',down_but_not_out=False)
        state=self.mm.configure(rid,host_token=a['host_token'],down_but_not_out=False,expected_revision=1)
        self.assertFalse(state['down_but_not_out'])
        self.assertEqual(state['settings_revision'],2)
        with self.assertRaises(Incompatible): self.mm.configure(rid,host_token=a['host_token'],down_but_not_out=True,expected_revision=1)
        started=self.mm.configure(rid,host_token=a['host_token'],started=True,expected_revision=2)
        self.assertTrue(started['started'])
        with self.assertRaises(Unsupported): self.mm.configure(rid,host_token=a['host_token'],down_but_not_out=True)
        self.assertFalse(self.mm._rooms[rid].dbno_enabled)
    def test_change_dbno_invalidates_old_pending_reservations(self):
        a=self.make('changing')
        rid=a['room']['room_id']
        ticket=self.mm.reserve(rid,player_id='waiting',protocol=7,game_build='native-yt-pin',level=65)
        self.assertEqual(self.mm._rooms[rid].occupancy(),2)
        self.mm.configure(rid,host_token=a['host_token'],down_but_not_out=False,expected_revision=1)
        self.assertEqual(self.mm._rooms[rid].occupancy(),1)
        with self.assertRaises(NotAuthorized):
            self.mm.confirm(rid,player_id='waiting',reservation_token=ticket['reservation_token'])

    def test_private_never_visible_even_with_matching_filters(self):
        self.make('private',password='genuine-password',down_but_not_out=False)
        self.assertEqual(self.browse(hide_full=False,min_open_slots=0,dbno=False),[])
    def test_invalid_values_rejected(self):
        a=self.make('validate')
        rid=a['room']['room_id']
        with self.assertRaises(LobbyError): self.mm.configure(rid,host_token=a['host_token'],down_but_not_out='no')
        with self.assertRaises(LobbyError): self.mm.browse(protocol=7,game_build='native-yt-pin',dbno='disabled')
        with self.assertRaises(LobbyError): self.mm.browse(protocol=7,game_build='native-yt-pin',min_open_slots=9)
        with self.assertRaises(LobbyError): self.mm.browse(protocol=7,game_build='native-yt-pin',scaling='ludicrous')

class HttpDbnoTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server=ThreadingHTTPServer(('127.0.0.1',0),handler_factory(Matchmaker()))
        cls.url='http://127.0.0.1:'+str(cls.server.server_port)
        cls.thread=Thread(target=cls.server.serve_forever,daemon=True)
        cls.thread.start()
    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join(timeout=2)
    def api(self,path,data=None,token=None):
        kwargs={'headers':{'Content-Type':'application/json'}}
        if token:kwargs['headers']['X-Hunter-Token']=token
        if data is not None: kwargs['data']=json.dumps(data).encode()
        req=Request(self.url+path,**kwargs)
        try:
            with urlopen(req,timeout=2) as r:return r.status,json.loads(r.read())
        except HTTPError as err:return err.code,json.loads(err.read())
    def test_http_filters_and_host_toggle(self):
        status,made=self.api('/v1/rooms',{'host_id':'httphost','title':'Hunt','protocol':7,'game_build':'yt',
                                           'down_but_not_out':False,'invasions_enabled':True,'scaling':'hard'})
        self.assertEqual(status,201)
        rid=made['room']['room_id']
        args=urlencode({'protocol':7,'game_build':'yt','level':60,'dbno':'off','invasion':'on','scaling':'hard'})
        status,rows=self.api('/v1/rooms?'+args)
        self.assertEqual(status,200)
        self.assertEqual([x['room_id'] for x in rows['rooms']],[rid])
        status,rows=self.api('/v1/rooms?protocol=7&game_build=yt&dbno=on')
        self.assertEqual((status,rows['rooms']),(200,[]))
        status,_=self.api('/v1/rooms/'+rid+'/configure',{'down_but_not_out':True})
        self.assertEqual(status,403)
        status,changed=self.api('/v1/rooms/'+rid+'/configure',{'down_but_not_out':True,'expected_revision':1},
                                token=made['host_token'])
        self.assertEqual((status,changed['down_but_not_out'],changed['settings_revision']),(200,True,2))
        status,_=self.api('/v1/rooms?protocol=7&game_build=yt&dbno=bogus')
        self.assertEqual(status,400)
    def test_http_quickplay_dbno_filters(self):
        self.api('/v1/rooms',{'host_id':'quickhost','title':'Quick','protocol':11,'game_build':'ytq',
                               'down_but_not_out':False})
        status,hit=self.api('/v1/quickplay',{'player_id':'guest001','protocol':11,'game_build':'ytq',
                                             'level':60,'dbno':True})
        self.assertEqual(status,404)
        status,hit=self.api('/v1/quickplay',{'player_id':'guest002','protocol':11,'game_build':'ytq',
                                             'level':60,'dbno':False})
        self.assertEqual(status,200)
        self.assertIn('reservation_token',hit)

if __name__=='__main__':unittest.main()
