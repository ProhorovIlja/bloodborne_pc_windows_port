import unittest, json, sys
from http.server import ThreadingHTTPServer
from pathlib import Path
from threading import Thread
from urllib.request import Request, urlopen
from urllib.error import HTTPError
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from matchmaking_http import handler_factory
from matchmaking import Matchmaker

class HttpPoCTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = ThreadingHTTPServer(('127.0.0.1',0),handler_factory(Matchmaker()))
        cls.base='http://127.0.0.1:'+str(cls.srv.server_port)
        cls.thread=Thread(target=cls.srv.serve_forever,daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()
        cls.srv.server_close()
        cls.thread.join(timeout=2)

    def fetch(self, path, data=None, method=None, token=None):
        headers={}
        if data is not None:
            data=json.dumps(data).encode()
            headers['Content-Type']='application/json'
        if token: headers['X-Hunter-Token']=token
        req=Request(self.base+path,data=data,headers=headers,method=method)
        try:
            with urlopen(req,timeout=3) as response:
                return response.status,json.loads(response.read()),response.headers
        except HTTPError as e:
            return e.code,json.loads(e.read()),e.headers

    def test_health_explicitly_not_data_plane(self):
        code,data,headers=self.fetch('/health')
        self.assertEqual(code,200)
        self.assertFalse(data['game_data_p2p'])
        self.assertFalse(data['live_game_integration'])
        self.assertEqual(headers['Cache-Control'],'no-store')

    def test_browser_and_quickplay(self):
        code,made,_=self.fetch('/v1/rooms',{'host_id':'hunter0','title':'Yharnam',
                                            'protocol':7,'game_build':'pin'},method='POST')
        self.assertEqual(code,201)
        rid=made['room']['room_id']
        code,rooms,_=self.fetch('/v1/rooms?protocol=7&game_build=pin&level=60')
        self.assertEqual(code,200)
        self.assertIn(rid,[r['room_id'] for r in rooms['rooms']])
        code,joined,_=self.fetch('/v1/quickplay',{'player_id':'hunter1','protocol':7,
                                                  'game_build':'pin','level':60},method='POST')
        self.assertEqual(code,200)
        self.assertEqual(joined['room_id'],rid)
        code,room,_=self.fetch('/v1/rooms/'+rid+'/confirm',{'player_id':'hunter1',
                     'reservation_token':joined['reservation_token']},method='POST')
        self.assertEqual((code,room['players']),(200,2))
        code,_,_=self.fetch('/v1/rooms/'+rid+'/configure',{'invasions_enabled':True},method='POST')
        self.assertEqual(code,403)
        code,room,_=self.fetch('/v1/rooms/'+rid+'/configure',{'invasions_enabled':True},
                               method='POST',token=made['host_token'])
        self.assertEqual(code,200)
        self.assertTrue(room['invasions_enabled'])

    def test_five_players_rejected(self):
        code,out,_=self.fetch('/v1/rooms',{'host_id':'hunter3','title':'Unsupported',
                                'protocol':7,'game_build':'pin','max_players':5},method='POST')
        self.assertEqual(code,409)
        self.assertEqual(out['error'],'unsupported')

if __name__=='__main__':unittest.main()
