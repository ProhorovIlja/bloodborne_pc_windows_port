import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from matchmaking import Matchmaker, LobbyError, NotAuthorized, NotFound, Full, Incompatible, Unsupported
from build_classifier import classify_build, presence_payload

BUILD = '77e3507'
PROTOCOL = 7

class LobbyTests(unittest.TestCase):
    def setUp(self):
        self.now = 10000
        self.m = Matchmaker(clock=lambda: self.now)

    def make(self, host='hunter0', title='The Dream', **options):
        return self.m.create(host_id=host, title=title, protocol=PROTOCOL, game_build=BUILD, **options)

    def reserve(self, room, player, **options):
        return self.m.reserve(room['room']['room_id'], player_id=player, protocol=PROTOCOL,
                              game_build=BUILD, level=60, **options)

    def test_multiple_independent_public_lobbies(self):
        a = self.make('hunter0', title='Cainhurst')
        b = self.make('hunter1', title='Yharnam')
        rooms = self.m.browse(protocol=PROTOCOL, game_build=BUILD, level=60)
        self.assertEqual(len(rooms), 2)
        self.assertEqual({r['title'] for r in rooms}, {'Cainhurst', 'Yharnam'})
        self.assertEqual({r['players'] for r in rooms}, {1})

    def test_password_rooms_hidden_and_password_not_exposed(self):
        a = self.make(password='mysecret', title='Private')
        self.assertFalse(self.m.browse(protocol=PROTOCOL, game_build=BUILD, level=60))
        with self.assertRaises(NotAuthorized): self.reserve(a, 'hunter1', password='wrong')
        t = self.reserve(a, 'hunter1', password='mysecret')
        self.assertNotIn('mysecret', str(t))
        state = self.m.confirm(a['room']['room_id'], player_id='hunter1', reservation_token=t['reservation_token'])
        self.assertEqual(state['players'], 2)

    def test_occupancy_and_capacity_no_double_book(self):
        a = self.make(max_players=2)
        token = self.reserve(a, 'hunter1')
        with self.assertRaises(Full): self.reserve(a, 'hunter2')
        state = self.m.confirm(a['room']['room_id'], player_id='hunter1', reservation_token=token['reservation_token'])
        self.assertEqual((state['players'], state['reserved']), (2, 0))
        with self.assertRaises(Full): self.reserve(a, 'hunter3')

    def test_reservation_expires_and_invalid_cannot_confirm(self):
        a = self.make(max_players=2)
        t = self.reserve(a, 'hunter1', ttl_ms=1000)
        self.now += 1000
        with self.assertRaises(NotAuthorized): self.m.confirm(a['room']['room_id'], player_id='hunter1', reservation_token=t['reservation_token'])
        self.assertEqual(self.reserve(a, 'hunter2')['room_id'], a['room']['room_id'])

    def test_quickplay_filters(self):
        a = self.make('hunter0', region='eu', min_level=30, max_level=100, invasions_enabled=False)
        self.make('hunter1', region='us', min_level=30, max_level=100, invasions_enabled=True)
        self.assertIsNone(self.m.quickplay(player_id='hunter2', protocol=PROTOCOL,
                                           game_build=BUILD, level=200, region='eu'))
        result = self.m.quickplay(player_id='hunter2', protocol=PROTOCOL,
                                  game_build=BUILD, level=80, region='eu', invasion=False)
        self.assertEqual(result['room_id'], a['room']['room_id'])

    def test_mismatched_protocol_build_blocked(self):
        a = self.make()
        with self.assertRaises(Incompatible):
            self.m.reserve(a['room']['room_id'], player_id='hunter1', protocol=8,
                           game_build=BUILD, level=60)
        with self.assertRaises(Incompatible):
            self.m.reserve(a['room']['room_id'], player_id='hunter1', protocol=7,
                           game_build='wrong', level=60)

    def test_host_controls_settings(self):
        a = self.make()
        with self.assertRaises(NotAuthorized):
            self.m.configure(a['room']['room_id'], host_token='bad', invasions_enabled=True)
        state = self.m.configure(a['room']['room_id'], host_token=a['host_token'],
                                 invasions_enabled=True, scaling='hard', started=True)
        self.assertEqual((state['invasions_enabled'], state['scaling'], state['started']), (True, 'hard', True))
        self.assertFalse(self.m.browse(protocol=PROTOCOL, game_build=BUILD))

    def test_p2p_hint_requires_member_auth_and_is_not_data_plane(self):
        a = self.make()
        t = self.reserve(a, 'hunter1')
        self.m.confirm(a['room']['room_id'], player_id='hunter1', reservation_token=t['reservation_token'])
        with self.assertRaises(NotAuthorized):
            self.m.transport_plan(a['room']['room_id'], player_id='hunter1', token='wrong', direct_capable=True)
        plan = self.m.transport_plan(a['room']['room_id'], player_id='hunter1',
                                     token=t['reservation_token'], direct_capable=True)
        self.assertEqual(plan['mode'], 'p2p-attempt-then-relay')
        self.assertIn('not implemented', plan['note'])

    def test_fifth_player_not_falsely_enabled(self):
        with self.assertRaises(Unsupported): self.make(max_players=5)
        with self.assertRaises(Unsupported): Matchmaker(max_players=5)

    def test_concurrent_reservations_do_not_overbook(self):
        from concurrent.futures import ThreadPoolExecutor
        a = self.make(max_players=4)
        room_id = a['room']['room_id']
        def try_join(idx):
            try:
                self.reserve(a, f'hunter{idx}')
                return True
            except Full:
                return False
        with ThreadPoolExecutor(max_workers=12) as pool:
            joined = list(pool.map(try_join, range(1, 40)))
        self.assertEqual(sum(joined), 3)
        self.assertEqual(len(self.m._rooms[room_id].reservations), 3)

    def test_close_requires_host(self):
        a = self.make()
        with self.assertRaises(NotAuthorized): self.m.close(a['room']['room_id'], host_token='bad')
        self.m.close(a['room']['room_id'], host_token=a['host_token'])
        with self.assertRaises(NotFound): self.reserve(a, 'hunter1')


class Builds(unittest.TestCase):
    def stats(self, **kwargs):
        return dict(strength=10, skill=10, arcane=10, bloodtinge=10, **kwargs)

    def test_early_skill(self):
        self.assertEqual(classify_build({'strength':10,'skill':18,'arcane':9,'bloodtinge':10}), 'Skill')

    def test_quality(self):
        self.assertEqual(classify_build({'strength':20,'skill':22,'arcane':10,'bloodtinge':10}), 'Quality')

    def test_skill_bloodtinge(self):
        self.assertEqual(classify_build({'strength':10,'skill':20,'arcane':10,'bloodtinge':18}), 'Skill/Bloodtinge')

    def test_arcane(self):
        self.assertEqual(classify_build({'strength':10,'skill':12,'arcane':20,'bloodtinge':10}), 'Arcane')

    def test_developing(self):
        self.assertEqual(classify_build({'strength':12,'skill':16,'arcane':10,'bloodtinge':14}), 'Developing')

    def test_presence_optout_and_stats(self):
        stats={'strength':20,'skill':20,'arcane':10,'bloodtinge':9}
        self.assertIsNone(presence_payload(blood_level=60, stats=stats, privacy=True))
        value=presence_payload(blood_level=60, stats=stats, party_size=2)
        self.assertEqual(value['details'], 'Bloodborne | BL 60')
        self.assertEqual(value['state'], 'Quality')
        self.assertEqual(value['partySize'], 2)

if __name__=='__main__': unittest.main()
