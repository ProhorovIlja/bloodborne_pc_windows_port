// SPDX-License-Identifier: GPL-2.0-or-later
#ifdef NDEBUG
#undef NDEBUG
#endif
#include "session_matchmaking.hpp"
#include <cassert>
#include <iostream>
using namespace SeamlessHunt::InGame;
static Party PartyOf(std::string id,std::string member){return {id,{{member,60}}};}
static Room BuildRoom(std::string id,bool dbno,bool invade,Scaling scaling=Scaling::PartyBalanced){
    Room r;r.id=id;r.title=id;r.game_build="pinned-yt";r.region="eu";
    r.rules.dbno_enabled=dbno;r.rules.invasions_enabled=invade;
    r.rules.invasion_slots=2;r.rules.scaling=scaling;
    r.defenders.push_back(PartyOf("host-"+id,"player-"+id));return r;
}
int main(){
    const auto now=Matchmaker::Clock::now();
    Matchmaker mm;
    assert(mm.Create(BuildRoom("on",true,true,Scaling::Challenging)));
    assert(mm.Create(BuildRoom("off",false,false)));
    auto look=PartyOf("searcher","visitor");
    assert(mm.Browse(look,Mode::Coop,"pinned-yt",now).size()==2);
    RoomFilters f;f.dbno=true;f.invasions=true;f.scaling=Scaling::Challenging;
    auto found=mm.Browse(look,Mode::Coop,"pinned-yt",now,f);
    assert(found.size()==1&&found.front().id=="on"&&found.front().dbno_enabled);
    assert(mm.QuickPlay(look,Mode::Coop,"pinned-yt",now,f)==std::optional<std::string>("on"));
    f.dbno=false;assert(mm.Browse(look,Mode::Coop,"pinned-yt",now,f).empty());
    f.dbno.reset();f.invasions=false;f.scaling.reset();
    assert(mm.QuickPlay(look,Mode::Coop,"pinned-yt",now,f)==std::optional<std::string>("off"));
    auto old=mm.Snapshot("on");assert(old&&old->rules_revision==1);
    auto next=old->rules;next.dbno_enabled=false;
    assert(!mm.Configure("on","visitor",next,1));
    assert(!mm.Configure("on","player-on",next,99));
    assert(mm.Configure("on","player-on",next,1));
    assert(mm.Snapshot("on")->rules_revision==2);
    assert(!mm.Configure("on","player-on",next,1));
    assert(mm.StartHunt("on","player-on"));
    assert(!mm.Configure("on","player-on",old->rules,3));
    f={};f.include_started=true;f.dbno=false;
    assert(mm.Browse(look,Mode::Coop,"pinned-yt",now,f).size()==2);
    auto private_r=BuildRoom("secret",true,true);private_r.rules.password_protected=true;
    assert(mm.Create(private_r));
    assert(mm.Browse(look,Mode::Coop,"pinned-yt",now).size()==1);
    assert(mm.Browse(look,Mode::Invasion,"pinned-yt",now).empty());
    assert(CanJoin(private_r,look,Mode::Invasion,"pinned-yt",true).reject==Reject::Private);
    auto full=BuildRoom("full",true,true);
    full.rules.total_slots=2;
    assert(mm.Create(full));
    auto ticket=mm.Reserve("full",PartyOf("lastparty","lastplayer"),Mode::Coop,"pinned-yt",false,now);
    assert(ticket && mm.Confirm(ticket->id,now));
    RoomFilters show;show.min_free_slots=0;show.hide_full=false;
    auto rows=mm.Browse(look,Mode::Coop,"pinned-yt",now,show);
    bool saw_full=false;for(const auto& v:rows)if(v.id=="full"){
      saw_full=true;assert(!v.joinable && v.free_slots==0 && v.reason==Reject::Full);
    }
    assert(saw_full);
    assert(mm.QuickPlay(look,Mode::Coop,"pinned-yt",now,show)!=std::optional<std::string>("full"));
    std::cout<<"PASS: DBNO filters, PvP/scaling filters, Quick Play, host rule revision, started lock, full preview\n";
}
