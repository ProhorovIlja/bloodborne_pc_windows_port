// SPDX-License-Identifier: GPL-2.0-or-later
#ifdef NDEBUG
#undef NDEBUG
#endif
#include "invasion_lifecycle.hpp"
#include <cassert>
#include <iostream>
using namespace SeamlessHunt::InGame;
static std::vector<Combatant> Fight(){return {
    {"host","allies",BattleSide::Defender,BattleVital::Standing,900},
    {"ally","allies",BattleSide::Defender,BattleVital::Standing,600},
    {"inv1","attackers",BattleSide::Invader,BattleVital::Standing,500},
    {"inv2","attackers",BattleSide::Invader,BattleVital::Standing,700}};}
int main(){
    InvasionEncounter on(Fight());
    assert(on.Valid()&&on.Down("inv1").event==BattleEvent::Downed);
    assert(on.Get("inv1")->vital==BattleVital::Down);
    assert(on.VerifiedReviveHit("inv2","inv1",500,1).event==BattleEvent::Revived);
    InvasionEncounter off(Fight(),false);
    assert(off.Valid()&&off.Down("inv1").event==BattleEvent::Eliminated);
    assert(off.Get("inv1")->vital==BattleVital::Gone);
    assert(off.VerifiedReviveHit("inv2","inv1",500,1).refusal==HitRefusal::DbnoDisabled);
    assert(!off.Resolved());
    auto wipe=off.Down("inv2");
    assert(wipe.event==BattleEvent::InvadersDefeated);
    assert(wipe.return_to_home.size()==2);
    assert(off.Resolved());
    InvasionEncounter defendersOff(Fight(),false);
    assert(defendersOff.Down("ally").event==BattleEvent::Eliminated);
    assert(defendersOff.VerifiedReviveHit("host","ally",900,2).refusal==HitRefusal::DbnoDisabled);
    assert(defendersOff.Get("host")->vital==BattleVital::Standing);
    std::cout<<"PASS: DBNO ON revive, OFF normal elimination, no revives, party return-home\n";
}
