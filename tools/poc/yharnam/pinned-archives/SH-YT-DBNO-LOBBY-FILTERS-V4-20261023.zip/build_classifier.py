"""Privacy-safe build/Rich-Presence metadata, not connected to game memory yet."""
from __future__ import annotations

ALLOWED = ('strength', 'skill', 'bloodtinge', 'arcane')
NAMES = {'strength': 'Strength', 'skill': 'Skill', 'bloodtinge': 'Bloodtinge', 'arcane': 'Arcane'}
PAIR_NAMES = {
    frozenset(('strength', 'skill')): 'Quality',
    frozenset(('strength', 'bloodtinge')): 'Strength/Bloodtinge',
    frozenset(('skill', 'bloodtinge')): 'Skill/Bloodtinge',
    frozenset(('strength', 'arcane')): 'Strength/Arcane',
    frozenset(('skill', 'arcane')): 'Skill/Arcane',
    frozenset(('bloodtinge', 'arcane')): 'Bloodtinge/Arcane',
}


def classify_build(stats: dict[str, int], *, threshold: int = 18, tolerance: int = 9) -> str:
    """Heuristic only: prioritizes offensive attributes; origin-dependent variance is possible.

    18 is the early classification threshold, not a confirmed final build.
    Include a second attribute only if it is within 9 points of the leader.
    """
    if not 15 <= threshold <= 40:
        raise ValueError('threshold must be 15..40')
    if not 0 <= tolerance <= 15:
        raise ValueError('tolerance must be 0..15')
    if any(k not in stats for k in ALLOWED):
        raise ValueError('all four offensive stats are required')
    values = {key: stats[key] for key in ALLOWED}
    if any(type(n) is not int or not 1 <= n <= 99 for n in values.values()):
        raise ValueError('stats must be integers in 1..99')
    maximum = max(values.values())
    if maximum < threshold:
        return 'Developing'
    focus = sorted((k for k in ALLOWED if values[k] >= threshold and maximum - values[k] <= tolerance),
                   key=lambda k: (-values[k], ALLOWED.index(k)))
    if len(focus) == 1:
        return NAMES[focus[0]]
    if len(focus) == 2:
        return PAIR_NAMES[frozenset(focus)]
    return 'Hybrid (' + '/'.join(NAMES[k] for k in focus) + ')'


def presence_payload(*, blood_level: int, stats: dict[str, int], party_size: int = 1,
                     max_party_size: int = 4, privacy: bool = False) -> dict | None:
    """Opt-in Rich Presence data; does not call Discord or transmit player information."""
    if privacy:
        return None
    if not 4 <= blood_level <= 544 or not 1 <= party_size <= max_party_size <= 4:
        raise ValueError('invalid Blood Level / player count')
    build = classify_build(stats)
    return {'details': 'Bloodborne | BL ' + str(blood_level), 'state': build,
            'partySize': party_size, 'partyMax': max_party_size,
            'note': 'Local metadata only; Discord application integration not implemented'}
