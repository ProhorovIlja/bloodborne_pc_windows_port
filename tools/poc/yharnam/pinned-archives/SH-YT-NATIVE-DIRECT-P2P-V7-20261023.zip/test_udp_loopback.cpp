// SPDX-License-Identifier: GPL-2.0-or-later
// Real POSIX UDP loopback smoke. This is NOT an actual Bloodborne client.
#ifdef NDEBUG
#undef NDEBUG
#endif
#include "native_shlk_direct.hpp"
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>
#include <cassert>
#include <array>
#include <cstring>
#include <iostream>
using namespace SeamlessHunt::Direct;
struct Udp {
  int fd=-1;std::uint16_t port=0;
  Udp() {
    fd=::socket(AF_INET,SOCK_DGRAM,0);assert(fd>=0);
    sockaddr_in a{};a.sin_family=AF_INET;a.sin_port=0;a.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
    assert(::bind(fd,reinterpret_cast<sockaddr*>(&a),sizeof(a))==0);
    socklen_t n=sizeof(a);assert(::getsockname(fd,reinterpret_cast<sockaddr*>(&a),&n)==0);
    port=ntohs(a.sin_port);
    timeval timeout{.tv_sec=1,.tv_usec=0};
    assert(::setsockopt(fd,SOL_SOCKET,SO_RCVTIMEO,&timeout,sizeof(timeout))==0);
  }
  ~Udp(){if(fd>=0)::close(fd);}
  Udp(const Udp&)=delete;Udp& operator=(const Udp&)=delete;
  void Send(const std::vector<std::uint8_t>& bytes,std::uint16_t dest){
    sockaddr_in a{};a.sin_family=AF_INET;a.sin_port=htons(dest);a.sin_addr.s_addr=htonl(INADDR_LOOPBACK);
    assert(::sendto(fd,bytes.data(),bytes.size(),0,reinterpret_cast<sockaddr*>(&a),sizeof(a))==static_cast<ssize_t>(bytes.size()));
  }
  std::vector<std::uint8_t> Recv(){
    std::array<std::uint8_t,2000> b{};
    auto n=::recv(fd,b.data(),b.size(),0);assert(n>=0);return {b.begin(),b.begin()+n};
  }
};
int main(){
  Udp a_sock,b_sock,relay_sock;
  Identity ida,idb;for(unsigned n=0;n<16;n++)ida.room[n]=static_cast<std::uint8_t>(n+1);
  for(unsigned n=0;n<32;n++)ida.pair_secret[n]=static_cast<std::uint8_t>(n+2);
  ida.epoch=8;ida.self_virtual={0x0a1c1d1e,3658};ida.peer_virtual={0x0a1c1d1f,3658};
  idb=ida;std::swap(idb.self_virtual,idb.peer_virtual);
  DirectSession a(ida),b(idb);
  a.Candidate({0x7f000001,b_sock.port},true);b.Candidate({0x7f000001,a_sock.port},true);
  auto x=a.Tick(1000);auto y=b.Tick(1000);
  for(const auto& v:x) a_sock.Send(v.bytes,b_sock.port);
  for(const auto& v:y) b_sock.Send(v.bytes,a_sock.port);
  for(unsigned i=0;i<x.size();i++){
    auto dat=b_sock.Recv();auto result=b.Receive(dat.data(),dat.size(),{0x7f000001,a_sock.port},1001);
    for(const auto& e:result.second)b_sock.Send(e.bytes,a_sock.port);
  }
  for(unsigned i=0;i<y.size();i++){
    auto dat=a_sock.Recv();auto result=a.Receive(dat.data(),dat.size(),{0x7f000001,b_sock.port},1001);
    for(const auto& e:result.second)a_sock.Send(e.bytes,b_sock.port);
  }
  // Process ACK and PONG. Must process both before direct is confirmed.
  for(unsigned i=0;i<x.size();i++){
    auto dat=a_sock.Recv();a.Receive(dat.data(),dat.size(),{0x7f000001,b_sock.port},1002);
  }
  for(unsigned i=0;i<y.size();i++){
    auto dat=b_sock.Recv();b.Receive(dat.data(),dat.size(),{0x7f000001,a_sock.port},1002);
  }
  assert(a.Direct()&&b.Direct());
  const std::vector<std::uint8_t> game{0x01,0x02,0x03,0x04,0x42,0x24,0x12};
  auto tx=a.SendGame(game.data(),game.size(),1010);
  assert(tx&&tx->path==Path::Direct);
  a_sock.Send(tx->bytes,b_sock.port);
  auto raw=b_sock.Recv();auto rx=b.Receive(raw.data(),raw.size(),{0x7f000001,a_sock.port},1011);
  assert(rx.first && rx.first->virtual_from==ida.self_virtual && rx.first->game_frame==game);
  // After dead-link timeout the *game packet* still reaches peer via our test relay.
  a.Tick(5000);assert(!a.Direct());
  auto fallback=a.SendGame(game.data(),game.size(),5001);
  assert(fallback&&fallback->path==Path::Relay);
  a_sock.Send(fallback->bytes,relay_sock.port);
  auto via_server=relay_sock.Recv();assert(via_server==game);
  relay_sock.Send(via_server,b_sock.port);
  auto delivered=b_sock.Recv();assert(delivered==game);
  // Oversize direct data must fall back rather than being silently lost.
  std::vector<std::uint8_t> big(1400,0x71);
  assert(a.SendGame(big.data(),big.size(),5005)->path==Path::Relay);
  std::cout<<"PASS real native UDP sockets: direct authenticated frame, stable virtual identity, auto relay fallback, large-frame preservation\n";
}
