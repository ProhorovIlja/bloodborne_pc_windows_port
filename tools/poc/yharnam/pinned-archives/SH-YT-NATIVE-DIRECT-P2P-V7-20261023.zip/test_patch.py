"""Fail-closed pinned-target patch tests; no original checkout needed."""
import importlib.util
import pathlib
import unittest

ROOT=pathlib.Path(__file__).resolve().parent
s=importlib.util.spec_from_file_location('patch_native',ROOT/'PATCH-BBPORT-NATIVE-DIRECT-V7.py')
m=importlib.util.module_from_spec(s)
s.loader.exec_module(m)

class PatchTests(unittest.TestCase):
    def fixture(self):
        return '\n'.join((m.INSERT_INCLUDE,m.INSERT_SEND,m.INSERT_RECEIVE,
                          m.INSERT_TICK,m.INSERT_FIELD,m.INSERT_RESET))
    def test_six_exact_native_insertions(self):
        result=m.patch(self.fixture())
        self.assertIn('native_direct.TryGame',result)
        self.assertIn('native_direct.Receive',result)
        self.assertIn('native_direct.Tick',result)
        self.assertIn('native_direct.Reset',result)
        self.assertIn('NativeAdapter native_direct',result)
        self.assertIn('SHD7',result)
        self.assertIn('EncodeData',result) if 'EncodeData' in result else self.assertIn(m.INSERT_SEND,result)
    def test_duplicate_source_anchor_rejected(self):
        with self.assertRaises(ValueError): m.patch(self.fixture()+'\n'+m.INSERT_SEND)
    def test_missing_anchor_rejected(self):
        with self.assertRaises(ValueError):m.patch(self.fixture().replace(m.INSERT_TICK,'removed'))
    def test_patch_is_not_idempotent(self):
        with self.assertRaises(ValueError):m.patch(m.patch(self.fixture()))
    def test_original_unmodified(self):
        content=self.fixture();m.patch(content)
        self.assertNotIn('NativeAdapter',content)
    def test_default_no_server_authorization(self):
        # Source instrumentation exists but installing a candidate is ONLY
        # possible through an authenticated server-extension still outstanding.
        source=m.patch(self.fixture())
        self.assertNotIn('native_direct.Authorize(',source)
        self.assertIn('if (auto sh_direct = native_direct.TryGame(',source)
if __name__=='__main__':unittest.main()
