// SPDX-License-Identifier: GPL-2.0-or-later
#ifdef NDEBUG
#undef NDEBUG
#endif
#include "native_shlk_adapter.hpp"
#include <cassert>
#include <iostream>
using namespace SeamlessHunt::Direct;
int main(){
  Identity aa;aa.epoch=20;aa.self_virtual={0x0a000002,3658};aa.peer_virtual={0x0a000003,3658};
  for(unsigned n=0;n<32;n++)aa.pair_secret[n]=static_cast<std::uint8_t>(n+1);
  for(unsigned n=0;n<16;n++)aa.room[n]=static_cast<std::uint8_t>(n+6);
  Identity bb=aa;std::swap(bb.self_virtual,bb.peer_virtual);
  NativeAdapter a,b;
  Endpoint phys_a{0x7f000001,60010},phys_b{0x7f000001,60011};
  assert(!a.Authorize(aa,phys_b,false));
  assert(!a.TryGame(aa.peer_virtual,std::array<std::uint8_t,5>{1,2,3,4,5},1000));
  assert(a.Authorize(aa,phys_b,true));
  assert(b.Authorize(bb,phys_a,true));
  std::vector<std::uint8_t> frame{0x34,0x12,0x78,0x56,42};
  assert(!a.TryGame(aa.peer_virtual,frame,900));
  auto tx_a=a.Tick(1000),tx_b=b.Tick(1000);
  for(auto& tx:tx_a){auto received=b.Receive(tx.bytes,phys_a,1001);
    assert(received.recognized);
    for(auto& answer:received.replies){auto back=a.Receive(answer.bytes,phys_b,1002);
      assert(back.recognized);}}
  for(auto& tx:tx_b){auto received=a.Receive(tx.bytes,phys_b,1001);
    assert(received.recognized);
    for(auto& answer:received.replies){auto back=b.Receive(answer.bytes,phys_a,1002);
      assert(back.recognized);}}
  auto direct=a.TryGame(aa.peer_virtual,frame,1010);
  assert(direct && direct->physical==phys_b);
  auto rx=b.Receive(direct->bytes,phys_a,1011);
  assert(rx.data && rx.data->virtual_from==aa.self_virtual && rx.data->game_frame==frame);
  assert(!b.Receive(direct->bytes,phys_a,1012).data);
  auto fake=b.Receive(direct->bytes,Endpoint{0x7f000001,11111},1013);
  assert(fake.recognized&&!fake.data);
  a.Tick(5000);assert(!a.TryGame(aa.peer_virtual,frame,5001));
  a.Remove(aa.peer_virtual);a.Reset();
  assert(!a.TryGame(aa.peer_virtual,frame,5005));
  std::cout<<"PASS native BBPort socket adapter route, authorization gate, virtual source, failback, reset\n";
}
