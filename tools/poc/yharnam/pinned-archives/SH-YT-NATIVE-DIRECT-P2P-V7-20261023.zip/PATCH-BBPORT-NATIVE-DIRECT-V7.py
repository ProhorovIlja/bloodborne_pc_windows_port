#!/usr/bin/env python3
"""Fail-closed pinned-source BBPort socket route integration.

Requires FUTURE authenticated shadNet candidate handler calling
P2PTransport::native_direct.Authorize (not present in this milestone).
The runtime remains relay-only until that authenticated control-plane is wired.
"""
import argparse
import pathlib
import subprocess
PIN='77e350743a7cb4524cfcc1782fb6e3af64e25b15'
FILE='emulator/src/core/libraries/network/p2p_sockets.cpp'

INSERT_INCLUDE='#include "core/libraries/network/server_link.h"'
INSERT_RECEIVE='            const std::span<const u8> datagram{buffer.data(), static_cast<size_t>(rc)};'
INSERT_SEND='        // The server link: the frame goes to shadNet, which hands it to the peer.'
INSERT_TICK='        link_tick_ms = now_ms;'
INSERT_FIELD='    net_socket host_socket{kInvalidSocket};'
INSERT_RESET='    void ConfigureLink(u32 server_addr_nbo, u16 server_port_nbo, std::string online_id,\n                       std::string secret) {'

def patch(content):
    if "native_shlk_adapter.hpp" in content or "native_direct.TryGame(" in content:
        raise ValueError("already patched; refuse double instrumentation")
    rules=[
    (INSERT_INCLUDE,INSERT_INCLUDE+'\n#include "native_shlk_adapter.hpp"'),
    (INSERT_SEND,'''
        // Native Seamless Hunt: direct peers use the same physical UDP socket.
        // Without a server-authenticated mutual-consent candidate this does NOTHING.
        const auto sh_dest = SeamlessHunt::Direct::Endpoint{ntohl(dest_addr_nbo),
                                                             ntohs(dest_port_nbo)};
        if (auto sh_direct = native_direct.TryGame(sh_dest, framed, P2PNowMs())) {
            sockaddr_in sh_peer{};
            sh_peer.sin_family = AF_INET;
            sh_peer.sin_addr.s_addr = htonl(sh_direct->physical.ipv4);
            sh_peer.sin_port = htons(sh_direct->physical.port);
            if (Transmit(sh_peer, std::move(sh_direct->bytes))) {
                return static_cast<int>(len);
            }
            // The direct UDP send failed: immediately relay the ORIGINAL game frame.
            native_direct.Remove(sh_dest);
        }
''' +INSERT_SEND),
    (INSERT_RECEIVE,INSERT_RECEIVE+'''
            // SHD7 is never delivered as a raw game frame. Decode + authenticate
            // and restore the original virtual peer address for the game.
            auto sh_rx = native_direct.Receive(datagram,
                {ntohl(from.sin_addr.s_addr),ntohs(from.sin_port)},P2PNowMs());
            if (sh_rx.recognized) {
                for (auto& reply : sh_rx.replies) {
                    sockaddr_in sh_reply{};
                    sh_reply.sin_family=AF_INET;
                    sh_reply.sin_addr.s_addr=htonl(reply.physical.ipv4);
                    sh_reply.sin_port=htons(reply.physical.port);
                    Transmit(sh_reply,std::move(reply.bytes));
                }
                if (sh_rx.data) {
                    Deliver(htonl(sh_rx.data->virtual_from.ipv4),
                            htons(sh_rx.data->virtual_from.port),sh_rx.data->game_frame);
                }
                continue;
            }
'''),
    (INSERT_TICK,INSERT_TICK+'''
        // Pump native direct probes/keepalives on the reader thread.
        for (auto& direct_tx : native_direct.Tick(now_ms)) {
            sockaddr_in sh_addr{};
            sh_addr.sin_family=AF_INET;
            sh_addr.sin_addr.s_addr=htonl(direct_tx.physical.ipv4);
            sh_addr.sin_port=htons(direct_tx.physical.port);
            Transmit(sh_addr,std::move(direct_tx.bytes));
        }
'''),
    (INSERT_FIELD,'    SeamlessHunt::Direct::NativeAdapter native_direct;\n'+INSERT_FIELD),
    (INSERT_RESET,INSERT_RESET+'\n        native_direct.Reset(); // never keep a peer credential across server changes'),
    ]
    for needle,addition in rules:
        times=content.count(needle)
        if times!=1:raise ValueError(f'Wrong pinned source: {needle[:70]!r}, count={times}')
        content=content.replace(needle,addition,1)
    return content

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--checkout',type=pathlib.Path,required=True)
    parser.add_argument('--out',type=pathlib.Path,required=True)
    a=parser.parse_args();src=a.checkout.resolve();out=a.out.resolve()
    if out==src or src in out.parents: parser.error('output must not be inside upstream checkout')
    actual=subprocess.check_output(['git','-C',str(src),'rev-parse','HEAD'],text=True).strip()
    if actual!=PIN:raise SystemExit('wrong upstream revision: '+actual)
    if out.exists() and any(out.iterdir()):raise SystemExit('output is not empty; refuse to overwrite')
    original=(src/FILE).read_text('utf-8')
    modified=patch(original) # fail before writing anything
    target=out/FILE;target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(modified,'utf-8')
    package=pathlib.Path(__file__).resolve().parent
    for name in ('native_shlk_direct.hpp','native_shlk_adapter.hpp'):
        (target.parent/name).write_bytes((package/name).read_bytes())
    print('PATCH_OK: BBPort source now has optional native SHD7 direct hooks')
    print('STATUS: inactive until a server-authenticated candidate/consent control plane exists')
if __name__=='__main__':main()
