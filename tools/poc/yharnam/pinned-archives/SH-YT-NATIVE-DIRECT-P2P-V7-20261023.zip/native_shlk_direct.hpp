// SPDX-License-Identifier: GPL-2.0-or-later
// Native Seamless Hunt direct-peer UDP data channel (experimental, not yet in BBPort binary).
// AUTHORIZATION REQUIREMENT: sessions are installed ONLY from authenticated shadNet
// same-room membership and opt-in; never from untrusted peer discovery or LAN broadcasts.
#pragma once
#include <openssl/hmac.h>
#include <openssl/crypto.h>
#include <array>
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <deque>
#include <map>
#include <optional>
#include <stdexcept>
#include <vector>

namespace SeamlessHunt::Direct {
constexpr std::size_t kHeader=4+1+1+16+6+6+8+8+8+2;
constexpr std::size_t kTag=16;
constexpr std::size_t kMaxPayload=1100;
constexpr std::int64_t kDirectDeadMs=2400;
constexpr std::int64_t kProbeEveryMs=250;
constexpr std::int64_t kPingEveryMs=500;

enum class Type : std::uint8_t { Probe=1, Ack=2, Ping=3, Pong=4, Game=5 };
enum class Path : std::uint8_t { Relay=0, Direct=1 };
struct Endpoint { std::uint32_t ipv4=0; std::uint16_t port=0; bool operator==(const Endpoint&)const=default; };
struct Identity {
  std::array<std::uint8_t,16> room{};
  Endpoint self_virtual{},peer_virtual{};  // 10.x.y.z:3658, stable across NAT/route switches
  std::array<std::uint8_t,32> pair_secret{};
  std::uint64_t epoch=0;  // shadNet issues epoch per authorized party membership
};
struct Packet {
  Type type=Type::Probe;
  std::array<std::uint8_t,16> room{};
  Endpoint source{},dest{};
  std::uint64_t epoch=0,seq=0,stamp_ms=0;
  std::vector<std::uint8_t> payload;
};
inline void U16(std::vector<std::uint8_t>& b,std::uint16_t v){b.push_back(v>>8);b.push_back(v&255);}
inline void U32(std::vector<std::uint8_t>& b,std::uint32_t v){for(int s=24;s>=0;s-=8)b.push_back((v>>s)&255);}
inline void U64(std::vector<std::uint8_t>& b,std::uint64_t v){for(int s=56;s>=0;s-=8)b.push_back((v>>s)&255);}
inline std::uint16_t Read16(const std::uint8_t* p){return(std::uint16_t(p[0])<<8)|p[1];}
inline std::uint32_t Read32(const std::uint8_t* p){return (std::uint32_t(p[0])<<24)|(std::uint32_t(p[1])<<16)|(std::uint32_t(p[2])<<8)|p[3];}
inline std::uint64_t Read64(const std::uint8_t* p){std::uint64_t r=0;for(int n=0;n<8;n++)r=r<<8|p[n];return r;}
inline void PutEndpoint(std::vector<std::uint8_t>& out,Endpoint e){U32(out,e.ipv4);U16(out,e.port);}
inline bool KeyIsBlank(const std::array<std::uint8_t,32>& k){
  std::uint8_t all=0;for(auto byte:k)all|=byte;return all==0;
}
inline std::vector<std::uint8_t> Encode(const Packet& p,const std::array<std::uint8_t,32>& key){
  if(!p.seq || !p.epoch || p.payload.size()>kMaxPayload || KeyIsBlank(key)) throw std::invalid_argument("untrusted direct packet");
  auto kind=static_cast<unsigned>(p.type);
  if(kind<1||kind>5)throw std::invalid_argument("unknown packet kind");
  std::vector<std::uint8_t> b; b.reserve(kHeader+p.payload.size()+kTag);
  b.insert(b.end(),{'S','H','D','7'});b.push_back(1);b.push_back(static_cast<std::uint8_t>(p.type));
  b.insert(b.end(),p.room.begin(),p.room.end());PutEndpoint(b,p.source);PutEndpoint(b,p.dest);
  U64(b,p.epoch);U64(b,p.seq);U64(b,p.stamp_ms);U16(b,static_cast<std::uint16_t>(p.payload.size()));
  b.insert(b.end(),p.payload.begin(),p.payload.end());
  unsigned int size=0;unsigned char mac[EVP_MAX_MD_SIZE]{};
  if(!HMAC(EVP_sha256(),key.data(),static_cast<int>(key.size()),b.data(),b.size(),mac,&size)||size<kTag)
    throw std::runtime_error("HMAC failure");
  b.insert(b.end(),mac,mac+kTag);return b;
}
inline std::optional<Packet> Decode(const std::uint8_t* b,std::size_t len,
                                     const std::array<std::uint8_t,32>& key){
  if(!b||len<kHeader+kTag||len>kHeader+kMaxPayload+kTag||KeyIsBlank(key))return {};
  if(std::memcmp(b,"SHD7",4)!=0||b[4]!=1||b[5]<1||b[5]>5)return {};
  const auto body_len=Read16(b+kHeader-2);
  if(body_len>kMaxPayload||len!=kHeader+body_len+kTag)return {};
  unsigned int mac_len=0;unsigned char mac[EVP_MAX_MD_SIZE]{};
  if(!HMAC(EVP_sha256(),key.data(),static_cast<int>(key.size()),b,len-kTag,mac,&mac_len)||mac_len<kTag||
     CRYPTO_memcmp(mac,b+len-kTag,kTag)!=0)return {};
  Packet p;p.type=static_cast<Type>(b[5]);std::memcpy(p.room.data(),b+6,16);
  p.source={Read32(b+22),Read16(b+26)};p.dest={Read32(b+28),Read16(b+32)};
  p.epoch=Read64(b+34);p.seq=Read64(b+42);p.stamp_ms=Read64(b+50);
  p.payload.assign(b+kHeader,b+kHeader+body_len);return p;
}

class ReplayWindow {
  static constexpr std::uint64_t kWidth=128;
  std::uint64_t highest_=0;std::array<std::uint64_t,2> bits_{};
public:
  bool Accept(std::uint64_t sequence){
    if(sequence==0)return false;
    if(sequence>highest_){
      const auto shift=sequence-highest_;
      if(shift>=kWidth){bits_={};}
      else if(shift>=64){bits_[1]=(bits_[0]<<(shift-64));bits_[0]=0;}
      else if(shift){bits_[1]=(bits_[1]<<shift)|(bits_[0]>>(64-shift));bits_[0]<<=shift;}
      highest_=sequence;
    }else if(highest_-sequence>=kWidth)return false;
    const std::uint64_t distance=highest_-sequence;
    auto& word=bits_[distance>=64?1:0];const std::uint64_t mask=1ULL<<(distance%64);
    if(word&mask)return false;
    word|=mask;return true;
  }
};
struct Emission { Path path=Path::Relay; std::vector<std::uint8_t> bytes; };
struct Incoming { Type type; Endpoint virtual_from; std::vector<std::uint8_t> game_frame; };

class DirectSession {
public:
  explicit DirectSession(Identity i):id_(std::move(i)){
    if(!id_.epoch || KeyIsBlank(id_.pair_secret) || id_.self_virtual==id_.peer_virtual ||
       id_.self_virtual.port==0 || id_.peer_virtual.port==0)throw std::invalid_argument("invalid direct membership");
  }
  // Candidate IP is server-observed, based on authenticated opt-in at shadNet.
  void Candidate(Endpoint observed_peer,bool authorized){
    candidate_=authorized&&observed_peer.ipv4&&observed_peer.port?std::optional<Endpoint>{observed_peer}:std::nullopt;
    direct_=false;got_probe_=false;got_ack_=false;last_seen_ms_=0;outstanding_probe_=0;pending_.clear();ping_ms_.clear();
  }
  bool Direct()const{return direct_;}
  Path Route()const{return direct_?Path::Direct:Path::Relay;}
  std::optional<Endpoint> CandidateEndpoint()const{return candidate_;}
  std::uint64_t RelayedBytes()const{return relayed_bytes_;}
  std::uint64_t DirectBytes()const{return direct_bytes_;}
  std::optional<std::uint32_t> DirectPingMs()const{
    if(ping_ms_.size()<3)return {};
    auto a=ping_ms_;std::sort(a.begin(),a.end());return a[a.size()/2];
  }
  std::vector<Emission> Tick(std::int64_t now){
    std::vector<Emission> outgoing;
    if(direct_&&now-last_seen_ms_>=kDirectDeadMs){direct_=false;got_probe_=false;got_ack_=false;}
    if(!candidate_)return outgoing;
    if(!direct_&&(last_probe_ms_<0||now-last_probe_ms_>=kProbeEveryMs)){
      outgoing.push_back({Path::Direct,Make(Type::Probe,{},now)});
      outstanding_probe_=seq_;last_probe_ms_=now;
    }
    if(last_ping_ms_<0||now-last_ping_ms_>=kPingEveryMs){
      auto frame=Make(Type::Ping,{},now);const auto seq=seq_;pending_[seq]=now;
      outgoing.push_back({Path::Direct,std::move(frame)});last_ping_ms_=now;
    }
    for(auto i=pending_.begin();i!=pending_.end();){
      if(now-i->second>kDirectDeadMs)i=pending_.erase(i);else ++i;
    }
    return outgoing;
  }
  // Receive ONLY after socket source == authorized observed peer endpoint. An
  // otherwise valid HMAC from an arbitrary Internet address MUST be discarded.
  std::pair<std::optional<Incoming>,std::vector<Emission>> Receive(
      const std::uint8_t* bytes,std::size_t len,Endpoint actual_sender,std::int64_t now){
    std::vector<Emission> responses;
    if(!candidate_||actual_sender!=*candidate_)return {{},responses};
    auto p=Decode(bytes,len,id_.pair_secret);
    if(!p||p->epoch!=id_.epoch||p->room!=id_.room||
       p->source!=id_.peer_virtual||p->dest!=id_.self_virtual||!replay_.Accept(p->seq))return {{},responses};
    last_seen_ms_=now;
    switch(p->type){
    case Type::Probe:
      got_probe_=true;
      {std::vector<std::uint8_t> nonce;U64(nonce,p->seq);
       responses.push_back({Path::Direct,Make(Type::Ack,std::move(nonce),now)});}
      break;
    case Type::Ack:
      if(p->payload.size()==8 && outstanding_probe_ && last_probe_ms_>=0 &&
         now>=last_probe_ms_ && now-last_probe_ms_<=1500 &&
         Read64(p->payload.data())==outstanding_probe_)got_ack_=true;
      break;
    case Type::Ping:{
      std::vector<std::uint8_t> seq;U64(seq,p->seq);
      responses.push_back({Path::Direct,Make(Type::Pong,seq,now)});break;}
    case Type::Pong:
      if(p->payload.size()==8){
        auto it=pending_.find(Read64(p->payload.data()));
        if(it!=pending_.end()&&now>=it->second&&now-it->second<5000){
          ping_ms_.push_back(static_cast<std::uint32_t>(now-it->second));
          if(ping_ms_.size()>11)ping_ms_.erase(ping_ms_.begin());
          pending_.erase(it);
        }
      }
      break;
    case Type::Game:
      if(direct_)return {{Incoming{p->type,p->source,std::move(p->payload)}},responses};
      break;
    }
    if(got_ack_&&got_probe_)direct_=true;
    return {{},responses};
  }
  // A game frame is the ORIGINAL 4-byte virtual-vport header + payload.
  // SHLK relay packet wrapping remains the caller's responsibility when route=Relay.
  std::optional<Emission> SendGame(const std::uint8_t* frame,std::size_t len,std::int64_t now){
    if(!frame||len<4||len>64000)return {};
    if(!direct_||!candidate_||len>kMaxPayload){relayed_bytes_+=len;return Emission{Path::Relay,{frame,frame+len}};}
    direct_bytes_+=len;
    return Emission{Path::Direct,Make(Type::Game,{frame,frame+len},now)};
  }
private:
  std::vector<std::uint8_t> Make(Type type,std::vector<std::uint8_t> data,std::int64_t now){
    return Encode(Packet{type,id_.room,id_.self_virtual,id_.peer_virtual,id_.epoch,++seq_,
                         static_cast<std::uint64_t>(now),std::move(data)},id_.pair_secret);
  }
  Identity id_;std::optional<Endpoint> candidate_;
  ReplayWindow replay_;std::uint64_t seq_=0,direct_bytes_=0,relayed_bytes_=0,outstanding_probe_=0;
  bool direct_=false,got_probe_=false,got_ack_=false;
  std::int64_t last_probe_ms_=-1,last_ping_ms_=-1,last_seen_ms_=0;
  std::map<std::uint64_t,std::int64_t> pending_;
  std::vector<std::uint32_t> ping_ms_;
};
} // namespace SeamlessHunt::Direct
