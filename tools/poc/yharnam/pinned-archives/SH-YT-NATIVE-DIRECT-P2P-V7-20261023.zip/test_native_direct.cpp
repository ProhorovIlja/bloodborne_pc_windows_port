// SPDX-License-Identifier: GPL-2.0-or-later
#ifdef NDEBUG
#undef NDEBUG
#endif
#include "native_shlk_direct.hpp"
#include <cassert>
#include <iostream>
#include <vector>
using namespace SeamlessHunt::Direct;
static Identity A(){
  Identity id;for(int i=0;i<16;i++)id.room[i]=static_cast<std::uint8_t>(i*7+1);
  for(int i=0;i<32;i++)id.pair_secret[i]=static_cast<std::uint8_t>(i*5+42);
  id.epoch=42;id.self_virtual={0x0a010203,3658};id.peer_virtual={0x0a010204,3658};return id;
}
static Identity B(){auto id=A();std::swap(id.self_virtual,id.peer_virtual);return id;}
static void Exchange(DirectSession& a,DirectSession& b,Endpoint pa,Endpoint pb,
                    std::int64_t now,const std::vector<Emission>& from_a,
                    const std::vector<Emission>& from_b){
  for(const auto& e:from_a){
    const auto [got,resp]=b.Receive(e.bytes.data(),e.bytes.size(),pa,now);
    assert(!got);
    for(const auto& reply:resp){auto [received,extra]=a.Receive(reply.bytes.data(),reply.bytes.size(),pb,now+1);
      assert(!received&&extra.empty());}
  }
  for(const auto& e:from_b){
    const auto [got,resp]=a.Receive(e.bytes.data(),e.bytes.size(),pb,now);
    assert(!got);
    for(const auto& reply:resp){auto [received,extra]=b.Receive(reply.bytes.data(),reply.bytes.size(),pa,now+1);
      assert(!received&&extra.empty());}
  }
}
int main(){
  const auto a_id=A(),b_id=B();
  DirectSession a(a_id),b(b_id);
  const Endpoint pa{0x7f000001,40001},pb{0x7f000001,40002};
  a.Candidate(pb,true);b.Candidate(pa,true);
  const std::vector<std::uint8_t> game{0x12,0x34,0xab,0xcd,0x11,0x22,0x33};
  auto initial=a.SendGame(game.data(),game.size(),100);
  assert(initial && initial->path==Path::Relay && initial->bytes==game);
  Exchange(a,b,pa,pb,1000,a.Tick(1000),b.Tick(1000));
  assert(a.Direct()&&b.Direct());
  auto direct=a.SendGame(game.data(),game.size(),1010);
  assert(direct&&direct->path==Path::Direct&&direct->bytes!=game);
  auto [delivered,answers]=b.Receive(direct->bytes.data(),direct->bytes.size(),pa,1011);
  assert(delivered && delivered->virtual_from==a_id.self_virtual);
  assert(delivered->game_frame==game && answers.empty());
  auto dup=b.Receive(direct->bytes.data(),direct->bytes.size(),pa,1012);
  assert(!dup.first);
  auto tampered=direct->bytes;tampered[10]^=0x80;
  assert(!b.Receive(tampered.data(),tampered.size(),pa,1013).first);
  assert(!b.Receive(direct->bytes.data(),direct->bytes.size(),Endpoint{0x7f000001,44444},1014).first);
  auto wrong=a_id;wrong.epoch=43;
  auto rogue=Encode(Packet{Type::Game,wrong.room,wrong.self_virtual,wrong.peer_virtual,
      wrong.epoch,333,1015,game},wrong.pair_secret);
  assert(!b.Receive(rogue.data(),rogue.size(),pa,1016).first);
  assert(a.DirectBytes()==game.size());assert(a.RelayedBytes()==game.size());
  // In a real game these timers are driven by the P2P reader loop.
  a.Tick(4000);assert(!a.Direct());
  auto recovered=a.SendGame(game.data(),game.size(),4001);
  assert(recovered&&recovered->path==Path::Relay&&recovered->bytes==game);
  // Session is rebound by the authenticated server, not guessed by a peer.
  const Endpoint new_pa{0x7f000001,50505};
  b.Candidate(new_pa,true);a.Candidate(pb,true);
  Exchange(a,b,new_pa,pb,5000,a.Tick(5000),b.Tick(5000));
  assert(a.Direct()&&b.Direct());
  // Whole-group privacy mode: no candidate, therefore no direct traffic.
  b.Candidate({},false);assert(!b.Direct());
  assert(b.SendGame(game.data(),game.size(),5100)->path==Path::Relay);
  // 128-bit replay-window out-of-order acceptance + dedup.
  ReplayWindow window;assert(window.Accept(130));assert(window.Accept(129));
  assert(!window.Accept(130));assert(!window.Accept(1));assert(window.Accept(300));
  assert(!window.Accept(130));
  std::cout<<"PASS native SHD7 authenticated game UDP: mutual probe, direct payload, stable virtual peer, replay, fallback, NAT rebind\n";
}
