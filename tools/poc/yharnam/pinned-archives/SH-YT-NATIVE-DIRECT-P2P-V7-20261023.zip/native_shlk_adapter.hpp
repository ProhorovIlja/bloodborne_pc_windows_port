// SPDX-License-Identifier: GPL-2.0-or-later
// BBPort socket-path adapter. Neither the endpoint nor keys can be filled from a user config.
// Call Authorize() only after shadNet has verified mutual membership, consent and
// issued a fresh room key/epoch over a confidential authenticated control channel.
#pragma once
#include "native_shlk_direct.hpp"
#include <map>
#include <memory>
#include <mutex>
#include <span>
namespace SeamlessHunt::Direct {
struct WireSend { Endpoint physical; std::vector<std::uint8_t> bytes; };
struct WireReceive {
  bool recognized=false;
  std::optional<Incoming> data;
  std::vector<WireSend> replies;
};
class NativeAdapter {
public:
  bool Authorize(Identity id, Endpoint observed_physical, bool mutual_consent) {
    std::scoped_lock lock(mu_);
    if(!mutual_consent || !observed_physical.ipv4 || !observed_physical.port)return false;
    const auto key=Key(id.peer_virtual);
    auto session=std::make_unique<DirectSession>(std::move(id));
    session->Candidate(observed_physical,true);
    slots_.insert_or_assign(key,std::move(session));
    return true;
  }
  void Remove(Endpoint peer){std::scoped_lock lock(mu_);slots_.erase(Key(peer));}
  void Reset(){std::scoped_lock lock(mu_);slots_.clear();}
  std::optional<WireSend> TryGame(Endpoint virtual_dest,std::span<const std::uint8_t> frame,std::int64_t now) {
    std::scoped_lock lock(mu_);
    auto it=slots_.find(Key(virtual_dest));
    if(it==slots_.end())return {};
    auto sent=it->second->SendGame(frame.data(),frame.size(),now);
    if(!sent || sent->path!=Path::Direct)return {};
    const auto candidate=it->second->CandidateEndpoint();
    if(!candidate)return {};
    return WireSend{*candidate,std::move(sent->bytes)};
  }
  std::vector<WireSend> Tick(std::int64_t now){
    std::scoped_lock lock(mu_);
    std::vector<WireSend> send;
    for(auto& [key,peer]:slots_){
      auto candidate=peer->CandidateEndpoint();
      if(!candidate)continue;
      for(auto& frame:peer->Tick(now))if(frame.path==Path::Direct)
        send.push_back({*candidate,std::move(frame.bytes)});
    }
    return send;
  }
  WireReceive Receive(std::span<const std::uint8_t> datagram,Endpoint actual_sender,std::int64_t now) {
    WireReceive out;
    if(datagram.size()<4||std::memcmp(datagram.data(),"SHD7",4)!=0)return out;
    out.recognized=true;
    std::scoped_lock lock(mu_);
    for(auto& [key,peer]:slots_){
      if(peer->CandidateEndpoint()!=std::optional<Endpoint>{actual_sender})continue;
      auto [received,responses]=peer->Receive(datagram.data(),datagram.size(),actual_sender,now);
      out.data=std::move(received);
      for(auto& response:responses)if(response.path==Path::Direct)
        out.replies.push_back({actual_sender,std::move(response.bytes)});
      break;
    }
    return out;
  }
  std::optional<std::uint32_t> Rtt(Endpoint virtual_peer) {
    std::scoped_lock lock(mu_);
    auto it=slots_.find(Key(virtual_peer));
    return it==slots_.end()?std::nullopt:it->second->DirectPingMs();
  }
private:
  static std::uint64_t Key(Endpoint e){return (std::uint64_t(e.ipv4)<<16)|e.port;}
  std::mutex mu_;
  std::map<std::uint64_t,std::unique_ptr<DirectSession>> slots_;
};
} // namespace SeamlessHunt::Direct
