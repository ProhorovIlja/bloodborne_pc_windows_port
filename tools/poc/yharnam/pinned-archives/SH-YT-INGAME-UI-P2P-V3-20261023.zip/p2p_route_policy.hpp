// SPDX-License-Identifier: GPL-2.0-or-later
#pragma once
// Conservative per-peer direct UDP route state machine. Pure C++ policy only;
// authentication and actual network send/receive belong to the native client.
#include <algorithm>
#include <cstdint>
#include <map>
#include <string>
#include <utility>
namespace SeamlessHunt::InGame {
enum class DataChannel { GameData, WorldControl, AccountRpc, LobbyControl };
enum class DirectState { Relay, Probing, Direct };
enum class Route { Relay, Direct };
struct RouteDecision { Route route{Route::Relay}; std::uint64_t epoch{}; };

class PeerRoutes {
public:
    // All time arguments are monotonic milliseconds, never wall-clock timestamps.
    explicit PeerRoutes(bool relay_only=false):relay_only_(relay_only){}
    void SetRelayOnly(bool flag) {
        if (relay_only_ == flag) return;
        relay_only_ = flag;
        if (flag) for (auto& [id,p]:peers_) Fallback(p);
    }
    // AUTHENTICATION BOUNDARY: the caller must first verify the signed,
    // expiring, room-scoped server candidate. Never pass untrusted peer IDs.
    // Caller must open direct socket/hole-punch only AFTER Begin succeeds.
    bool Begin(const std::string& peer, bool verified_server_candidate,
               std::int64_t now_ms, std::uint64_t attempt_nonce) {
        if (relay_only_ || !verified_server_candidate || peer.empty() || attempt_nonce == 0) return false;
        Peer& p = peers_[peer];
        if (p.state == DirectState::Direct && p.last_good_ms + kDeadMs > now_ms) return false;
        p.state=DirectState::Probing;
        p.attempt_nonce=attempt_nonce;
        p.last_probe_ms=now_ms;
        ++p.epoch;
        return true;
    }
    // MUST be called exclusively when the authenticated P2P handshake is
    // bidirectionally verified (same room, peer identities, nonce + epoch).
    bool Confirm(const std::string& peer, std::uint64_t nonce,
                 std::uint64_t epoch, bool verified_bidirectional, std::int64_t now_ms) {
        const auto it=peers_.find(peer);
        if (it==peers_.end() || !verified_bidirectional) return false;
        Peer& p=it->second;
        if (relay_only_ || p.state!=DirectState::Probing || p.epoch!=epoch ||
            p.attempt_nonce!=nonce || now_ms<p.last_probe_ms ||
            now_ms-p.last_probe_ms>kProbeTimeoutMs) return false;
        p.state=DirectState::Direct;
        p.last_good_ms=now_ms;
        ++p.epoch; // invalidate packets buffered for the previous relay route
        return true;
    }
    void PeerAuthenticatedTraffic(const std::string& peer, std::int64_t now_ms) {
        const auto it=peers_.find(peer);
        if (it!=peers_.end() && it->second.state==DirectState::Direct)
            it->second.last_good_ms=std::max(it->second.last_good_ms,now_ms);
    }
    // The actual packet handler must enforce per-channel game interest/party
    // filtering on direct and relay routes equally. A route decision is NOT
    // authorization to read packets of another team.
    RouteDecision Decide(const std::string& peer, DataChannel ch) const {
        const auto it=peers_.find(peer);
        const std::uint64_t epoch=it==peers_.end()?0:it->second.epoch;
        if (ch!=DataChannel::GameData || relay_only_ || it==peers_.end() ||
            it->second.state!=DirectState::Direct) return {Route::Relay,epoch};
        return {Route::Direct,epoch};
    }
    void Tick(std::int64_t now_ms) {
        for (auto& [id,p]:peers_) {
            if (p.state==DirectState::Direct && now_ms-p.last_good_ms>=kDeadMs) Fallback(p);
            else if (p.state==DirectState::Probing && now_ms-p.last_probe_ms>=kProbeTimeoutMs) Fallback(p);
        }
    }
    void Failed(const std::string& peer) {
        const auto it=peers_.find(peer);
        if (it!=peers_.end() && it->second.state!=DirectState::Relay) Fallback(it->second);
    }
    DirectState State(const std::string& peer) const {
        const auto it=peers_.find(peer);
        return it==peers_.end()?DirectState::Relay:it->second.state;
    }
    std::uint64_t Epoch(const std::string& peer) const {
        const auto it=peers_.find(peer);
        return it==peers_.end()?0:it->second.epoch;
    }
    static constexpr std::int64_t kProbeTimeoutMs=3500;
    static constexpr std::int64_t kDeadMs=3000;
private:
    struct Peer {
        DirectState state{DirectState::Relay};
        std::uint64_t epoch{};
        std::uint64_t attempt_nonce{};
        std::int64_t last_probe_ms{};
        std::int64_t last_good_ms{};
    };
    static void Fallback(Peer& p) {
        p.state=DirectState::Relay;
        p.attempt_nonce=0;
        ++p.epoch;
    }
    bool relay_only_=false;
    std::map<std::string,Peer> peers_;
};
} // namespace SeamlessHunt::InGame
