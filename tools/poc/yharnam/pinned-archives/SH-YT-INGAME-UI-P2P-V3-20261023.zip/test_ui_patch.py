#!/usr/bin/env python3
"""Source contract tests for pinned Yharnam overlay injection, without game assets."""
import importlib.util
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('ui_patch', HERE / 'PATCH-YHARNAM-TEAM-UI.py')
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)


def upstream_fixture():
    # These exact anchors were checked against pinned Yharnam Together upstream SHA.
    return '\n'.join([
        '#include "bbport_settings.h"',
        MODULE.OLD_SUBTITLE,
        'status = std::to_string(lobby.member_count) + T(" of 4", " из 4");',
        MODULE.OLD_HEADER,
        MODULE.OLD_CARD,
        '''    if (lobby.leader) {
        ImGui::PushFont(MenuArt::Font(), 19.0f);
        const ImVec2 remove_size(S(170.0f), S(38.0f));''',
    ])


class PinnedSourcePatch(unittest.TestCase):
    def test_patch_applies_all_features(self):
        result = MODULE.transform(upstream_fixture())
        for value in ('GetTeamScale()', 'SetTeamScalePercent(', 'sh_scale',
                      'sh_yharnam_layout.hpp', 'sh_yharnam_ui_scale.hpp',
                      'sh-scale-plus', 'sh-scale-minus', 'ImVec2& p = draw->VtxBuffer[v].pos',
                      '19.0f * sh_scale', 'std::to_string(BBCOOP_LOBBY_TEAM)'):
            self.assertIn(value, result)
        self.assertNotIn('of 4', result)

    def test_idempotence_fails_closed(self):
        once = MODULE.transform(upstream_fixture())
        with self.assertRaises(ValueError):
            MODULE.transform(once)

    def test_missing_anchor_fails_closed(self):
        before = upstream_fixture().replace(MODULE.OLD_CARD, '')
        with self.assertRaises(ValueError):
            MODULE.transform(before)

    def test_fixed_upstream_revision_expected(self):
        text = MODULE.OLD_HEADER
        self.assertIn('The four places', text)
        self.assertIn('290.0f', text)


if __name__ == '__main__':
    unittest.main(verbosity=2)
