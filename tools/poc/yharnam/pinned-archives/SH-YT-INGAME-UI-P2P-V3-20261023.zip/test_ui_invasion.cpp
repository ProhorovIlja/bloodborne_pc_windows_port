// SPDX-License-Identifier: GPL-2.0-or-later
#ifdef NDEBUG
#undef NDEBUG // tests are never silently disabled in Release builds
#endif
#include "hud_layout.hpp"
#include "invasion_lifecycle.hpp"
#include "session_matchmaking.hpp"
#include <cassert>
#include <cmath>
#include <iostream>
#include <vector>
using namespace SeamlessHunt::InGame;

static Party Pair(const std::string& id,const std::string& a,const std::string& b) {
    return Party{id,{{a,70},{b,70}}};
}
static Room TargetRoom(const std::string& id,bool password,bool enabled=true) {
    Room room;
    room.id=id; room.game_build="pinned-yt";
    room.defenders={Pair("defenders","host","ally")};
    room.rules.total_slots=4;
    room.rules.invasion_slots=2;
    room.rules.invasions_enabled=enabled;
    room.rules.password_protected=password;
    return room;
}
static void TestMatchmakingPrivacy() {
    const auto now=Matchmaker::Clock::now();
    const auto attackers=Pair("invaders","red","red2");
    Matchmaker mm;
    assert(mm.Create(TargetRoom("password",true)));
    assert(!mm.QuickPlay(attackers,Mode::Invasion,"pinned-yt",now));
    // No password protected session may be invaded, even with valid private-room authorization.
    const auto room=mm.Snapshot("password");
    assert(room);
    assert(CanJoin(*room,attackers,Mode::Invasion,"pinned-yt",true).reject==Reject::Private);
    assert(!mm.Reserve("password",attackers,Mode::Invasion,"pinned-yt",true,now));
    // Invite/password-verified co-op is still legal.
    assert(mm.Reserve("password",Party{"friend",{{"mate",70}}},Mode::Coop,
                      "pinned-yt",true,now));
    assert(mm.Create(TargetRoom("public",false)));
    assert(mm.QuickPlay(attackers,Mode::Invasion,"pinned-yt",now)==std::optional<std::string>("public"));
    auto t=mm.Reserve("public",attackers,Mode::Invasion,"pinned-yt",false,now);
    assert(t && mm.Confirm(t->id,now));
    assert(Players(*mm.Snapshot("public"))==4);
    auto p=TargetRoom("private",false);
    p.rules.visibility=Visibility::Private;
    assert(mm.Create(p));
    assert(CanJoin(p,attackers,Mode::Invasion,"pinned-yt",true).reject==Reject::Private);
    assert(mm.Create(TargetRoom("disabled",false,false)));
    assert(CanJoin(*mm.Snapshot("disabled"),attackers,Mode::Invasion,"pinned-yt",false).reject==
           Reject::InvasionsDisabled);
}

static void TestLayoutAndRoles() {
    constexpr float eps=.0001f;
    const auto four=TeamCards(1920,960,200,4);
    const auto five=TeamCards(1920,960,200,5);
    assert(std::abs(four.scale-1.0f)<eps);
    assert(five.count==5);
    assert(!five.needs_horizontal_scroll);
    assert(five.scale>0.79f && five.scale<0.81f);
    assert(std::abs(five.strip_width-four.strip_width)<eps);
    for(unsigned i=1;i<=5;++i) {
        auto screen=TeamCards(1280,640,160,i,1.1f);
        assert(screen.strip_width<=1280.0f-72.0f+eps);
        assert(!screen.needs_horizontal_scroll);
    }
    auto narrow=TeamCards(700,350,90,5,1.1f);
    assert(narrow.needs_horizontal_scroll); // don't make unreadable microscopic text
    assert(narrow.scale>=0.65f);
    assert(HudRows(3).scale==1.0f);
    assert(HudRows(4).scale==0.75f);
    assert(HudRows(4).text_height>=13.0f);
    assert(RoleEnglish(HunterRole::Invader)=="INVADER");
    assert(RoleRussian(HunterRole::Invader)=="ВТОРЖЕНЕЦ");
    assert(ToneFor(HunterRole::Invader)==RoleTone::Blood);
    assert(RoleEnglish(HunterRole::Defender)=="ALLY");
    assert(ToneFor(HunterRole::Host)==RoleTone::Gold);
}

static InvasionEncounter Duel() {
    return InvasionEncounter({
        {"host","defenders",BattleSide::Defender,BattleVital::Standing,800},
        {"ally","defenders",BattleSide::Defender,BattleVital::Standing,600},
        {"red1","redteam",BattleSide::Invader,BattleVital::Standing,500},
        {"red2","redteam",BattleSide::Invader,BattleVital::Standing,500}
    });
}
static void TestReviveAndDefeat() {
    auto encounter=Duel();
    assert(encounter.Valid());
    auto first=encounter.Down("red1");
    assert(first.event==BattleEvent::Downed && !encounter.Resolved());
    assert(encounter.Get("red1")->vital==BattleVital::Down);
    assert(encounter.VerifiedReviveHit("host","red1",500,11).refusal==HitRefusal::OpposingSide);
    assert(encounter.VerifiedReviveHit("ally","red1",500,12).refusal==HitRefusal::OpposingSide);
    assert(encounter.VerifiedReviveHit("red1","red1",500,13).refusal==HitRefusal::AttackerNotStanding);
    assert(encounter.VerifiedReviveHit("red2","red1",0,14).refusal==HitRefusal::ZeroDamage);
    auto progress=encounter.VerifiedReviveHit("red2","red1",300,15);
    assert(progress.event==BattleEvent::ReviveProgress && progress.revive_percent==60);
    assert(encounter.VerifiedReviveHit("red2","red1",300,15).refusal==HitRefusal::DuplicateHit);
    auto full=encounter.VerifiedReviveHit("red2","red1",200,16);
    assert(full.event==BattleEvent::Revived && full.revive_percent==100);
    assert(encounter.Get("red1")->vital==BattleVital::Standing);

    // Second down requires x2 maximum HP to revive.
    assert(encounter.Down("red1").event==BattleEvent::Downed);
    assert(ReviveNeeded(500,encounter.Get("red1")->down_count)==1000);
    auto second=encounter.VerifiedReviveHit("red2","red1",1000,17);
    assert(second.event==BattleEvent::Revived);

    assert(encounter.Down("red1").event==BattleEvent::Downed);
    // Both attackers defeated -> exactly two return-home commands, NOT account logouts.
    auto wipe=encounter.Down("red2");
    assert(wipe.event==BattleEvent::InvadersDefeated);
    assert(wipe.return_to_home.size()==2);
    assert(wipe.return_to_home[0]=="red1");
    assert(wipe.return_to_home[1]=="red2");
    assert(encounter.Resolved());
    assert(encounter.VerifiedReviveHit("red2","red1",500,18).refusal==HitRefusal::AlreadyResolved);
    assert(encounter.Get("host")->vital==BattleVital::Standing);
}

static void TestDistinctSidesAndExit() {
    auto e=InvasionEncounter({
        {"host","A",BattleSide::Defender,BattleVital::Standing,800},
        {"inv1","I",BattleSide::Invader,BattleVital::Standing,500},
        {"inv2","J",BattleSide::Invader,BattleVital::Standing,500}
    });
    assert(e.Down("inv1").event==BattleEvent::Downed);
    assert(e.VerifiedReviveHit("inv2","inv1",500,10).refusal==HitRefusal::OtherParty);
    auto v=e.Gone("inv2");
    assert(v.event==BattleEvent::InvadersDefeated);
    assert(v.return_to_home.size()==2);
    auto solo=InvasionEncounter({
        {"host","D",BattleSide::Defender,BattleVital::Standing,900},
        {"inv","I",BattleSide::Invader,BattleVital::Standing,700}
    });
    assert(solo.Down("inv").event==BattleEvent::InvadersDefeated);
    auto allies=Duel();
    assert(allies.Down("ally").event==BattleEvent::Downed);
    assert(allies.VerifiedReviveHit("red1","ally",2000,9).refusal==HitRefusal::OpposingSide);
    assert(allies.VerifiedReviveHit("host","ally",600,10).event==BattleEvent::Revived);
}

int main() {
    TestMatchmakingPrivacy();
    TestLayoutAndRoles();
    TestReviveAndDefeat();
    TestDistinctSidesAndExit();
    std::cout << "PASS: five-wide UI, role badges, password-safe invasions, invader-only revival, team defeat, return-home events\n";
}
