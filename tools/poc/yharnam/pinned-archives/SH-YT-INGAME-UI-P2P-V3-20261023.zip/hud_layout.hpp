// SPDX-License-Identifier: GPL-2.0-or-later
// Portable geometry/role logic for the actual in-game Bloodborne overlay adapter.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstddef>
#include <string_view>

namespace SeamlessHunt::InGame {

enum class HunterRole { Host, Defender, Invader };
enum class RoleTone { Gold, Bone, Blood };

inline std::string_view RoleEnglish(HunterRole role) {
    switch (role) {
    case HunterRole::Host: return "HOST";
    case HunterRole::Defender: return "ALLY";
    case HunterRole::Invader: return "INVADER";
    }
    return "HUNTER";
}
inline std::string_view RoleRussian(HunterRole role) {
    switch (role) {
    case HunterRole::Host: return "ХОСТ";
    case HunterRole::Defender: return "СОЮЗНИК";
    case HunterRole::Invader: return "ВТОРЖЕНЕЦ";
    }
    return "ОХОТНИК";
}
inline RoleTone ToneFor(HunterRole role) {
    switch (role) {
    case HunterRole::Host: return RoleTone::Gold;
    case HunterRole::Defender: return RoleTone::Bone;
    case HunterRole::Invader: return RoleTone::Blood;
    }
    return RoleTone::Bone;
}

// Team screen: fit up to 5 in ONE ROW within the space occupied by the old
// four 290x270 cards, without changing existing card art, fonts or aspect.
// Game-side UI scale: 0.65 to 1.10, auto-fit overrules too-large user value.
// For narrow/low-resolution screens, a horizontal scroll/selection strategy
// is preferable to text smaller than 65% of the intended size.
struct TeamStrip {
    float scale{1};
    float x{0}, y{0};
    float card_w{0}, card_h{0}, gap{0}, strip_width{0};
    unsigned count{0};
    bool needs_horizontal_scroll{false};
};
inline TeamStrip TeamCards(float viewport_width, float center_x, float y,
                           unsigned members, float user_scale=1.0f, float dpi=1.0f) {
    TeamStrip out;
    out.count=std::clamp(members,1u,5u);
    constexpr float kCardWidth=290.0f,kCardHeight=270.0f,kGap=24.0f;
    dpi=std::clamp(dpi,0.75f,3.0f);
    viewport_width=std::max(0.0f,viewport_width);
    const float baseline=(4*kCardWidth+3*kGap)*dpi; // old width: 1232
    const float available=std::min(baseline,std::max(0.0f,viewport_width-72.0f*dpi));
    const float base=(out.count*kCardWidth+(out.count-1)*kGap)*dpi;
    const float desired=std::clamp(user_scale,0.70f,1.10f);
    out.scale=std::min(desired,base>0 ? available/base : 1.0f);
    // Keep at least 65% to make the fonts usable; narrow screens scroll
    // horizontally (the in-game adapter must implement that input behavior).
    if(out.scale<0.65f) {
        out.scale=0.65f;
        out.needs_horizontal_scroll=true;
    }
    out.card_w=kCardWidth*dpi*out.scale;
    out.card_h=kCardHeight*dpi*out.scale;
    out.gap=kGap*dpi*out.scale;
    out.strip_width=out.count*out.card_w+(out.count-1)*out.gap;
    out.x=center_x-out.strip_width*0.5f;
    out.y=y;
    return out;
}
// Five total = four remote health bars. Scale to keep the same height as the
// old three-remote-member HUD without sacrificing explicit role labels.
struct HudStrip {
    float scale{1}, row_h{0}, text_height{0}, width{0}, total_height{0};
    unsigned rows{0};
};
inline HudStrip HudRows(unsigned remote_members,float user_scale=1.0f,float dpi=1.0f) {
    HudStrip out;
    out.rows=std::min(remote_members,4u);
    dpi=std::clamp(dpi,0.75f,3.0f);
    const float natural=50.0f*dpi;
    // Reference: three bars, each 50 high, in the existing HUD area.
    const float available=3.0f*natural;
    out.scale=out.rows==0?1.0f:std::min(std::clamp(user_scale,0.65f,1.10f),
                                        available/(natural*out.rows));
    out.row_h=natural*out.scale;
    out.text_height=std::max(13.0f*dpi,18.0f*dpi*out.scale);
    out.width=240.0f*dpi*out.scale;
    out.total_height=out.rows*out.row_h;
    return out;
}
} // namespace SeamlessHunt::InGame
