// SPDX-License-Identifier: GPL-2.0-or-later
#ifdef NDEBUG
#undef NDEBUG
#endif
#include "p2p_route_policy.hpp"
#include "sh_yharnam_ui_scale.hpp"
#include "invasion_lifecycle.hpp"
#include <cassert>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <iostream>
using namespace SeamlessHunt::InGame;
static void TestP2P(){
    PeerRoutes p;
    assert(p.Decide("guest",DataChannel::GameData).route==Route::Relay);
    assert(!p.Begin("guest",false,100,9));
    assert(!p.Begin("guest",true,100,0));
    assert(p.Begin("guest",true,100,9));
    auto epoch=p.Epoch("guest");
    assert(p.Decide("guest",DataChannel::GameData).route==Route::Relay);
    assert(!p.Confirm("guest",9,epoch,false,200));
    assert(!p.Confirm("guest",10,epoch,true,200));
    assert(!p.Confirm("guest",9,epoch+1,true,200));
    assert(p.Confirm("guest",9,epoch,true,200));
    auto direct=p.Decide("guest",DataChannel::GameData);
    assert(direct.route==Route::Direct && direct.epoch>epoch);
    for(const auto ch:{DataChannel::WorldControl,DataChannel::AccountRpc,DataChannel::LobbyControl})
        assert(p.Decide("guest",ch).route==Route::Relay);
    p.PeerAuthenticatedTraffic("guest",2000);
    p.Tick(4900);
    assert(p.State("guest")==DirectState::Direct);
    p.Tick(5000);
    assert(p.Decide("guest",DataChannel::GameData).route==Route::Relay);
    assert(p.Epoch("guest")>direct.epoch);
    assert(!p.Confirm("guest",9,epoch,true,5100));
    assert(p.Begin("guest",true,6000,10));
    const auto next=p.Epoch("guest");
    p.Tick(9500);
    assert(p.State("guest")==DirectState::Relay);
    assert(!p.Confirm("guest",10,next,true,9600));
    assert(p.Begin("guest",true,11000,11));
    assert(p.Confirm("guest",11,p.Epoch("guest"),true,11010));
    p.SetRelayOnly(true);
    assert(p.State("guest")==DirectState::Relay);
    assert(!p.Begin("guest",true,12000,12));
    assert(p.Decide("guest",DataChannel::GameData).route==Route::Relay);
}
static void TestScale(){
    namespace fs=std::filesystem;
    auto tmp=fs::temp_directory_path()/"sh-ingame-scale-test";
    fs::create_directories(tmp);
#ifdef _WIN32
    _putenv_s("BB_USER_DIR",tmp.string().c_str());
#else
    setenv("BB_USER_DIR",tmp.string().c_str(),1);
#endif
    assert(TeamScalePercent()==100);
    assert(GetTeamScale()==1.0f);
    assert(SetTeamScalePercent(55)==70);
    assert(SetTeamScalePercent(115)==110);
    assert(SetTeamScalePercent(87)==85);
    assert(GetTeamScale()==0.85f);
    std::ifstream f(tmp/"seamless-hunt-ui-scale.txt");
    int saved=0;f>>saved;
    assert(saved==85);
    f.close();
    fs::remove(tmp/"seamless-hunt-ui-scale.txt");
    fs::remove(tmp);
}
static void TestReviveDedupAcrossDifferentDowns(){
    InvasionEncounter e({
        {"def","D",BattleSide::Defender,BattleVital::Standing,500},
        {"inv1","I",BattleSide::Invader,BattleVital::Standing,500},
        {"inv2","I",BattleSide::Invader,BattleVital::Standing,500},
        {"inv3","I",BattleSide::Invader,BattleVital::Standing,500}
    });
    assert(e.Down("inv1").event==BattleEvent::Downed);
    assert(e.VerifiedReviveHit("inv2","inv1",100,40).event==BattleEvent::ReviveProgress);
    assert(e.Down("inv3").event==BattleEvent::Downed);
    assert(e.VerifiedReviveHit("inv2","inv1",100,40).refusal==HitRefusal::DuplicateHit);
}
int main(){TestP2P();TestScale();TestReviveDedupAcrossDifferentDowns();
    std::cout<<"PASS: persistent UI scale, P2P failover/epochs, trusted candidates, revive dedup\n";}
