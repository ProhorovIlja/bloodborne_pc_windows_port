// SPDX-License-Identifier: GPL-2.0-or-later
// Seamless Hunt: future server-authoritative invasion / party revive decision core.
// Safe to compile independently of Bloodborne. No network/game hooks in this file.
#pragma once
#include <algorithm>
#include <cstdint>
#include <limits>
#include <map>
#include <set>
#include <tuple>
#include <string>
#include <utility>
#include <vector>

namespace SeamlessHunt::InGame {
enum class BattleSide { Defender, Invader };
enum class BattleVital { Standing, Down, Gone };
enum class BattleEvent { None, Downed, ReviveProgress, Revived, InvadersDefeated };
enum class HitRefusal {
    None, NoSuchPlayer, AlreadyResolved, TargetNotDown, AttackerNotStanding,
    OpposingSide, OtherParty, ZeroDamage, DuplicateHit
};

struct Combatant {
    std::string player_id;
    std::string party_id;
    BattleSide side{BattleSide::Defender};
    BattleVital vital{BattleVital::Standing};
    std::uint32_t max_hp{1};
    std::uint32_t down_count{0};
    std::uint64_t revive_damage{0};
};

struct BattleDecision {
    BattleEvent event{BattleEvent::None};
    HitRefusal refusal{HitRefusal::None};
    std::uint32_t revive_percent{0};
    // When all invaders are Down/Gone, client must travel back to its OWN world;
    // the server must NOT log the player out or wipe the host's world.
    std::vector<std::string> return_to_home;
};

inline std::uint64_t ReviveNeeded(std::uint32_t max_hp, std::uint32_t down_count) {
    // Match existing BB seamless revive rule: 1x max HP on first down,
    // 2x on second, 4x on third and subsequent downs. Zero max HP => 1 minimum.
    const std::uint64_t factor = down_count <= 1 ? 1u : down_count == 2 ? 2u : 4u;
    return std::max<std::uint64_t>(1, max_hp) * factor;
}

class InvasionEncounter {
public:
    explicit InvasionEncounter(std::vector<Combatant> roster) {
        for (auto& c : roster) {
            if (c.player_id.empty() || c.party_id.empty()) {
                valid_ = false;
                continue;
            }
            if (!fighters_.emplace(c.player_id, std::move(c)).second) valid_ = false;
        }
        valid_ = valid_ && !fighters_.empty() &&
                 std::any_of(fighters_.begin(), fighters_.end(), [](const auto& kv) {
                     return kv.second.side == BattleSide::Defender;
                 }) &&
                 std::any_of(fighters_.begin(), fighters_.end(), [](const auto& kv) {
                     return kv.second.side == BattleSide::Invader;
                 });
    }

    bool Valid() const { return valid_; }
    bool Resolved() const { return resolved_; }
    const Combatant* Get(const std::string& id) const {
        const auto it = fighters_.find(id);
        return it == fighters_.end() ? nullptr : &it->second;
    }

    // Game runtime emits this only for an authenticated, real lethal/down event.
    BattleDecision Down(const std::string& id) {
        if (!valid_ || resolved_) return {.refusal=HitRefusal::AlreadyResolved, .return_to_home={}};
        auto it = fighters_.find(id);
        if (it == fighters_.end()) return {.refusal=HitRefusal::NoSuchPlayer, .return_to_home={}};
        if (it->second.vital != BattleVital::Standing) return {};
        auto& c = it->second;
        c.vital = BattleVital::Down;
        ++c.down_count;
        c.revive_damage = 0;
        // Per-target down epoch is part of the deduplication key below.
        // Do not clear hits for other downed players on this event.
        if (c.side == BattleSide::Invader && AllInvadersDefeated())
            return FinishInvaders();
        return {.event=BattleEvent::Downed, .return_to_home={}};
    }

    // A disconnected invader counts as eliminated for this visit, but not as
    // a logged-out account. The owning party and personal save persist.
    BattleDecision Gone(const std::string& id) {
        if (!valid_ || resolved_) return {.refusal=HitRefusal::AlreadyResolved, .return_to_home={}};
        auto it = fighters_.find(id);
        if (it == fighters_.end()) return {.refusal=HitRefusal::NoSuchPlayer, .return_to_home={}};
        it->second.vital = BattleVital::Gone;
        if (it->second.side == BattleSide::Invader && AllInvadersDefeated())
            return FinishInvaders();
        return {};
    }

    // verified_damage and hit_id MUST be verified/authoritative outputs from
    // the gameplay hit event, never arbitrary values supplied by a remote client.
    BattleDecision VerifiedReviveHit(const std::string& attacker,
                                     const std::string& target,
                                     std::uint64_t verified_damage,
                                     std::uint64_t hit_id) {
        if (!valid_ || resolved_) return {.refusal=HitRefusal::AlreadyResolved, .return_to_home={}};
        const auto from = fighters_.find(attacker);
        auto to = fighters_.find(target);
        if (from == fighters_.end() || to == fighters_.end())
            return {.refusal=HitRefusal::NoSuchPlayer, .return_to_home={}};
        if (to->second.vital != BattleVital::Down)
            return {.refusal=HitRefusal::TargetNotDown, .return_to_home={}};
        if (from->second.vital != BattleVital::Standing)
            return {.refusal=HitRefusal::AttackerNotStanding, .return_to_home={}};
        if (from->second.side != to->second.side)
            return {.refusal=HitRefusal::OpposingSide, .return_to_home={}};
        if (from->second.party_id != to->second.party_id)
            return {.refusal=HitRefusal::OtherParty, .return_to_home={}};
        if (verified_damage == 0) return {.refusal=HitRefusal::ZeroDamage, .return_to_home={}};
        // A hit can only count once, even if a reliable peer retransmits it.
        const auto key = std::make_tuple(target, to->second.down_count, hit_id);
        if (!used_hits_.insert(key).second)
            return {.refusal=HitRefusal::DuplicateHit, .return_to_home={}};
        const auto need = ReviveNeeded(to->second.max_hp, to->second.down_count);
        to->second.revive_damage = std::min<std::uint64_t>(
            need, to->second.revive_damage + std::min(verified_damage, need));
        const auto percent = static_cast<std::uint32_t>(to->second.revive_damage * 100 / need);
        if (to->second.revive_damage >= need) {
            to->second.vital = BattleVital::Standing;
            to->second.revive_damage = 0;
            return {.event=BattleEvent::Revived, .revive_percent=100, .return_to_home={}};
        }
        return {.event=BattleEvent::ReviveProgress, .revive_percent=percent, .return_to_home={}};
    }

private:
    bool AllInvadersDefeated() const {
        bool has_invaders = false;
        for (const auto& [id, c] : fighters_) {
            if (c.side != BattleSide::Invader) continue;
            has_invaders = true;
            if (c.vital == BattleVital::Standing) return false;
        }
        return has_invaders;
    }
    BattleDecision FinishInvaders() {
        resolved_ = true;
        BattleDecision out{};
        out.event=BattleEvent::InvadersDefeated;
        for (const auto& [id,c] : fighters_)
            if (c.side == BattleSide::Invader) out.return_to_home.push_back(id);
        return out;
    }
    bool valid_ = true;
    bool resolved_ = false;
    std::map<std::string,Combatant> fighters_;
    std::set<std::tuple<std::string,std::uint32_t,std::uint64_t>> used_hits_;
};
} // namespace SeamlessHunt::InGame
