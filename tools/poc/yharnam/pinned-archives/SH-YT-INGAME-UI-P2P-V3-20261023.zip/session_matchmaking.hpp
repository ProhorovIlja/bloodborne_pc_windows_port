// SPDX-License-Identifier: GPL-2.0-or-later
// Seamless Hunt: policy core for FUTURE in-game matchmaking.
// Not wired to live shadNet, the game's P2P stream, or PvP combat yet.
#pragma once
#include <algorithm>
#include <chrono>
#include <cstdint>
#include <map>
#include <mutex>
#include <optional>
#include <set>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace SeamlessHunt::InGame {
enum class Mode { Coop, Invasion };
enum class Visibility { Public, Private };
enum class Scaling { Vanilla, PartyBalanced, Challenging };
enum class RoutePreference { DirectP2P, RelayOnly };
enum class Reject { None, Closed, Private, InvasionsDisabled, InvasionCap, Full, InvalidGroup, MismatchedBuild, LevelMismatch, DuplicatePlayer, AlreadyReserved };

struct Hunter {
    std::string id;
    int level = 4;
};
struct Party {
    std::string id;
    std::vector<Hunter> members;
};
struct Rules {
    Visibility visibility = Visibility::Public;
    Scaling scaling = Scaling::PartyBalanced;
    RoutePreference route = RoutePreference::DirectP2P;
    bool invasions_enabled = false;
    bool password_protected = false; // no random invasion or Quick Play in a passworded room
    unsigned total_slots = 4;   // current client has 4 slots; 5 must pass runtime certification
    unsigned invasion_slots = 0;
    int level_tolerance = 40;
};
struct Room {
    std::string id;
    std::string game_build;
    Rules rules;
    std::vector<Party> defenders;
    std::vector<Party> invaders;
    bool open = true;
};
struct Admission {
    Reject reject = Reject::None;
    unsigned free_slots = 0;
    explicit operator bool() const { return reject == Reject::None; }
};
inline unsigned Count(const std::vector<Party>& ps) {
    unsigned n = 0;
    for (const Party& p : ps) n += static_cast<unsigned>(p.members.size());
    return n;
}
inline unsigned Players(const Room& r) { return Count(r.defenders) + Count(r.invaders); }
inline int HostLevel(const Room& r) {
    return r.defenders.empty() || r.defenders.front().members.empty() ? 0 : r.defenders.front().members.front().level;
}
inline bool UniqueMembers(const Party& group) {
    if (group.id.empty() || group.members.empty()) return false;
    std::set<std::string> ids;
    for (const auto& p : group.members) {
        if (p.id.empty() || p.level < 4 || p.level > 544 || !ids.insert(p.id).second) return false;
    }
    return true;
}
inline Admission CanJoin(const Room& r, const Party& group, Mode mode, std::string_view client_build,
                         bool server_authorized_private, unsigned reserved = 0,
                         unsigned reserved_invaders = 0, bool five_slot_runtime_certified = false) {
    const unsigned hard_limit = five_slot_runtime_certified ? 5u : 4u;
    if (!r.open) return {Reject::Closed};
    if (!UniqueMembers(group)) return {Reject::InvalidGroup};
    if (r.game_build.empty() || r.game_build != client_build) return {Reject::MismatchedBuild};
    if ((r.rules.visibility == Visibility::Private || r.rules.password_protected) &&
        !server_authorized_private) return {Reject::Private};
    // Invasion is never allowed into password-protected/private sessions, even with a valid invite.
    if (mode == Mode::Invasion &&
        (r.rules.visibility == Visibility::Private || r.rules.password_protected)) return {Reject::Private};
    if (r.defenders.empty() || !UniqueMembers(r.defenders.front())) return {Reject::InvalidGroup};
    for (const Party* p : [&] {
             std::vector<const Party*> all;
             for (const auto& q : r.defenders) all.push_back(&q);
             for (const auto& q : r.invaders) all.push_back(&q);
             return all;
         }()) {
        if (group.id == p->id) return {Reject::DuplicatePlayer};
        for (const auto& member : group.members)
            for (const auto& present : p->members)
                if (member.id == present.id) return {Reject::DuplicatePlayer};
    }
    if (mode == Mode::Invasion && !r.rules.invasions_enabled) return {Reject::InvasionsDisabled};
    if (mode == Mode::Invasion && Count(r.invaders) + reserved_invaders + group.members.size() > r.rules.invasion_slots)
        return {Reject::InvasionCap};
    if (Players(r) + reserved + group.members.size() > std::min(r.rules.total_slots, hard_limit))
        return {Reject::Full};
    if (std::any_of(group.members.begin(), group.members.end(), [&](const Hunter& h) {
            return std::abs(h.level - HostLevel(r)) > r.rules.level_tolerance;
        })) return {Reject::LevelMismatch};
    return {Reject::None, std::min(r.rules.total_slots, hard_limit) - Players(r) - reserved -
                              static_cast<unsigned>(group.members.size())};
}

// Server-side, per-room atomic capacity reservations. These are ephemeral; persist real rooms/credentials elsewhere.
// Caller MUST authenticate player IDs and private-room authorization separately, never trust a client boolean.
class Matchmaker {
public:
    using Clock = std::chrono::steady_clock;
    using Time = Clock::time_point;
    struct Ticket { std::string id; std::string room_id; Mode mode; Party party; Time until; };
    explicit Matchmaker(bool five_slot_runtime_certified = false) : certified_(five_slot_runtime_certified) {}
    bool Create(Room room) {
        if (room.id.empty() || room.game_build.empty() || room.defenders.size() != 1 ||
            !UniqueMembers(room.defenders.front()) || room.rules.total_slots < Players(room) ||
            room.rules.total_slots > (certified_ ? 5u : 4u) || room.rules.invasion_slots > room.rules.total_slots ||
            room.rules.level_tolerance < 0 || room.rules.level_tolerance > 544 || !room.invaders.empty()) return false;
        std::scoped_lock lock(mu_);
        return rooms_.emplace(room.id, std::move(room)).second;
    }
    std::optional<std::string> QuickPlay(const Party& party, Mode mode, std::string_view build,
                                         Time now) {
        std::scoped_lock lock(mu_);
        Expire(now);
        for (auto& [id, room] : rooms_) {
            if (room.rules.visibility != Visibility::Public || room.rules.password_protected) continue;
            const auto [taken, hostile] = Reserved(id);
            if (CanJoin(room, party, mode, build, false, taken, hostile, certified_)) return id;
        }
        return std::nullopt;
    }
    std::optional<Ticket> Reserve(std::string room_id, Party party, Mode mode,
                                  std::string_view build, bool server_authorized_private,
                                  Time now, std::chrono::seconds ttl = std::chrono::seconds{20}) {
        std::scoped_lock lock(mu_);
        Expire(now);
        if (ttl <= std::chrono::seconds{0} || ttl > std::chrono::seconds{60}) return std::nullopt;
        const auto found = rooms_.find(room_id);
        if (found == rooms_.end()) return std::nullopt;
        for (const auto& [id, t] : tickets_)
            for (const auto& h : party.members)
                for (const auto& reserved : t.party.members)
                    if (h.id == reserved.id) return std::nullopt;
        const auto [taken, hostile] = Reserved(room_id);
        if (!CanJoin(found->second, party, mode, build, server_authorized_private, taken, hostile, certified_))
            return std::nullopt;
        const Ticket ticket{std::to_string(++next_id_), std::move(room_id), mode, std::move(party), now + ttl};
        tickets_.emplace(ticket.id, ticket);
        return ticket;
    }
    bool Confirm(std::string_view ticket_id, Time now) {
        std::scoped_lock lock(mu_);
        Expire(now);
        const auto t = tickets_.find(std::string(ticket_id));
        if (t == tickets_.end()) return false;
        auto room = rooms_.find(t->second.room_id);
        if (room == rooms_.end() || !room->second.open) { tickets_.erase(t); return false; }
        // Recheck under the same mutex. The ticket itself already owns its capacity.
        if (t->second.mode == Mode::Invasion) room->second.invaders.push_back(t->second.party);
        else room->second.defenders.push_back(t->second.party);
        tickets_.erase(t);
        return true;
    }
    bool Close(std::string_view room_id) {
        std::scoped_lock lock(mu_);
        auto it = rooms_.find(std::string(room_id));
        if (it == rooms_.end()) return false;
        it->second.open = false;
        for (auto t = tickets_.begin(); t != tickets_.end();)
            if (t->second.room_id == room_id) t = tickets_.erase(t); else ++t;
        return true;
    }
    std::optional<Room> Snapshot(std::string_view room_id) const {
        std::scoped_lock lock(mu_);
        const auto it = rooms_.find(std::string(room_id));
        return it == rooms_.end() ? std::nullopt : std::optional<Room>{it->second};
    }
private:
    std::pair<unsigned,unsigned> Reserved(const std::string& room) const {
        unsigned all = 0, hostile = 0;
        for (const auto& [id,t] : tickets_) if (t.room_id == room) {
            const auto n = static_cast<unsigned>(t.party.members.size());
            all += n;
            if (t.mode == Mode::Invasion) hostile += n;
        }
        return {all, hostile};
    }
    void Expire(Time now) {
        for (auto it = tickets_.begin(); it != tickets_.end();)
            if (now >= it->second.until) it = tickets_.erase(it); else ++it;
    }
    bool certified_ = false;
    mutable std::mutex mu_;
    std::map<std::string,Room> rooms_;
    std::map<std::string,Ticket> tickets_;
    std::uint64_t next_id_ = 0;
};
} // namespace SeamlessHunt::InGame
