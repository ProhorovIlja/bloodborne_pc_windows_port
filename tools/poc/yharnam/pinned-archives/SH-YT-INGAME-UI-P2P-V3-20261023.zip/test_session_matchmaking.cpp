// SPDX-License-Identifier: GPL-2.0-or-later
#ifdef NDEBUG
#undef NDEBUG // ensure assertions execute even in Release builds
#endif
#include "session_matchmaking.hpp"
#include <cassert>
#include <thread>
#include <vector>
#include <iostream>
using namespace SeamlessHunt::InGame;
using Clock = Matchmaker::Clock;
static Party P(std::string id, std::initializer_list<std::string> members, int level=70) {
    Party p; p.id = std::move(id);
    for (auto& m:members) p.members.push_back({m,level});
    return p;
}
static Room R(std::string id, unsigned size=4) {
    Room r; r.id=std::move(id); r.game_build="pinned-yt"; r.defenders.push_back(P("host-party",{"a","b"}));
    r.rules.total_slots=size; r.rules.invasions_enabled=true; r.rules.invasion_slots=2;
    return r;
}
int main() {
    auto now=Clock::now();
    {
        Matchmaker m;
        assert(m.Create(R("r1")));
        assert(m.Create(R("r2")));
        auto q=m.QuickPlay(P("g1",{"c"}),Mode::Coop,"pinned-yt",now);
        assert(q && *q=="r1");
        auto t=m.Reserve("r1",P("g1",{"c"}),Mode::Coop,"pinned-yt",false,now);
        assert(t && m.Confirm(t->id,now));
        auto r=m.Snapshot("r1");
        assert(r && r->defenders.size()==2 && Players(*r)==3);
        assert(!m.Reserve("r1",P("g1",{"c"}),Mode::Coop,"pinned-yt",false,now));
        assert(!m.Reserve("r1",P("g2",{"d","e"}),Mode::Invasion,"pinned-yt",false,now));
        assert(m.Close("r1"));
        assert(!m.Reserve("r1",P("g3",{"d"}),Mode::Coop,"pinned-yt",false,now));
    }
    {
        Matchmaker m;
        auto r=R("invasion");
        assert(m.Create(r));
        auto inv=m.Reserve("invasion",P("invaders",{"x","y"}),Mode::Invasion,"pinned-yt",false,now);
        assert(inv && m.Confirm(inv->id,now));
        auto snapshot=m.Snapshot("invasion");
        assert(snapshot && snapshot->defenders.size()==1 && snapshot->invaders.size()==1);
        assert(Players(*snapshot)==4);
        assert(!m.Reserve("invasion",P("more",{"z"}),Mode::Invasion,"pinned-yt",false,now));
    }
    {
        auto r=R("five",5);
        assert(CanJoin(r,P("duo",{"x","y"}),Mode::Invasion,"pinned-yt",false,0,0,true));
        Matchmaker guarded;
        assert(!guarded.Create(r)); // 5 disabled until game runtime is proven.
        Matchmaker experimental(true);
        assert(experimental.Create(r));
        // Three defenders + 2 attacking from a separate party, exactly five.
        assert(experimental.Reserve("five",P("more-def",{"c"}),Mode::Coop,"pinned-yt",false,now));
    }
    {
        Matchmaker m;
        auto r=R("password");r.rules.visibility=Visibility::Private;
        assert(m.Create(r));
        assert(!m.QuickPlay(P("g",{"c"}),Mode::Coop,"pinned-yt",now));
        assert(!m.Reserve("password",P("g",{"c"}),Mode::Coop,"pinned-yt",false,now));
        assert(m.Reserve("password",P("g",{"c"}),Mode::Coop,"pinned-yt",true,now));
    }
    {
        Matchmaker m;
        auto r=R("noinvasion");r.rules.invasions_enabled=false;
        assert(m.Create(r));
        assert(!m.Reserve("noinvasion",P("bad",{"c"}),Mode::Invasion,"pinned-yt",false,now));
    }
    {
        Matchmaker m;
        auto r=R("build"); r.rules.level_tolerance=10;
        assert(m.Create(r));
        assert(!m.Reserve("build",P("g",{"c"}),Mode::Coop,"other-build",false,now));
        assert(!m.Reserve("build",P("g",{"c"},150),Mode::Coop,"pinned-yt",false,now));
        assert(!m.Reserve("build",P("bad",{"c","c"}),Mode::Coop,"pinned-yt",false,now));
    }
    {
        Matchmaker m;
        assert(m.Create(R("ttl")));
        auto t=m.Reserve("ttl",P("hold",{"c","d"}),Mode::Coop,"pinned-yt",false,now,std::chrono::seconds{1});
        assert(t);
        assert(!m.Reserve("ttl",P("other",{"e"}),Mode::Coop,"pinned-yt",false,now));
        assert(!m.Confirm(t->id,now+std::chrono::seconds{2}));
        assert(m.Reserve("ttl",P("other",{"e"}),Mode::Coop,"pinned-yt",false,now+std::chrono::seconds{2}));
    }
    {
        Matchmaker m;
        assert(m.Create(R("race")));
        std::atomic<int> admitted=0;
        std::vector<std::thread> threads;
        for (int i=0;i<16;++i) threads.emplace_back([&,i]{
            auto t=m.Reserve("race",P("p"+std::to_string(i),{"u"+std::to_string(i)}),Mode::Coop,"pinned-yt",false,now);
            if(t && m.Confirm(t->id,now)) admitted.fetch_add(1);
        });
        for(auto& t:threads)t.join();
        assert(admitted==2); // host starts with 2, so exactly 2 more are admitted.
    }
    std::cout << "PASS: concurrent reservations, many rooms, private/quick play, 2+2 invasions, certified 5-slot policy, version/level, TTL\n";
}
