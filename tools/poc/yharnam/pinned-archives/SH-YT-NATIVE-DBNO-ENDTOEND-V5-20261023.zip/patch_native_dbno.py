#!/usr/bin/env python3
"""Fail-closed source patch: host DBNO setting from in-game Team screen to shadNet and death hooks.

Target ONLY lKaniel/bloodborne-server commit 77e350743a7cb4524cfcc1782fb6e3af64e25b15.
Source-only, does not compile, deploy, modify original checkout or touch Fornex.
"""
from __future__ import annotations
import argparse
import pathlib
import subprocess
import sys

PIN='77e350743a7cb4524cfcc1782fb6e3af64e25b15'

def once(text: str, anchor: str, replacement: str, label: str) -> str:
    found=text.count(anchor)
    if found!=1:
        raise ValueError(f'{label}: expected one anchor, got {found}')
    return text.replace(anchor,replacement,1)

def patch_proto(s):
    s=once(s, '    PROTOCOL_CURRENT = 7;',
           '    PROTOCOL_CURRENT = 8; // DBNO host rule in TeamRequest/Team', 'wire protocol version')
    s=once(s, '        FORGET_WORLD = 11;\n',
           '        FORGET_WORLD = 11;\n        SET_DBNO = 12; // host toggles Down But Not Out before the hunt begins\n', 'proto action')
    s=once(s, '    string world = 6;\n}\n\nmessage LobbyPlayer {',
           '    string world = 6;\n    bool dbno_enabled = 7; // for SET_DBNO, false means normal death\n}\n\nmessage LobbyPlayer {','proto request bit')
    s=once(s, '    string party = 7;\n}\n\nmessage TeamInvite {',
           '    string party = 7;\n    optional bool dbno_enabled = 8; // unset on old teams means ON (compatibility)\n}\n\nmessage TeamInvite {','proto team field')
    return s

def patch_server(s):
    s=once(s, '        team.set_leader(member);\n        bbcoop::TeamMember& m = *team.add_members();',
           '        team.set_leader(member);\n        team.set_dbno_enabled(true); // current YT behavior until host changes it\n        bbcoop::TeamMember& m = *team.add_members();', 'server team defaults')
    s=once(s, '    switch (request.action()) {\n    case Action::CREATE: {',
           '''    switch (request.action()) {
    case Action::SET_DBNO: {
        if (!mine || mine->leader() != member) {
            return refuse("only the team's leader changes DBNO");
        }
        if (mine->started()) {
            return refuse("DBNO is locked after the hunt starts");
        }
        if (mine->has_dbno_enabled() && mine->dbno_enabled() == request.dbno_enabled()) {
            return {}; // no revision or broadcast for duplicate request
        }
        mine->set_dbno_enabled(request.dbno_enabled());
        return {.changed = true}; // Settle broadcasts updated lobby state
    }
    case Action::CREATE: {''','server action')
    return s

def patch_client_header(s):
    return once(s, 'void TeamLobbyRequest(bbcoop::TeamRequest::Action action, const std::string& id);',
                'void TeamLobbyRequest(bbcoop::TeamRequest::Action action, const std::string& id);\n'
                'void TeamSetDbno(bool enabled);\n'
                'bool TeamDbnoEnabled(); // authoritative team setting; missing means legacy ON', 'client method declarations')

def patch_client_world(s):
    s=once(s, 'std::string TeamLobbyMember() {\n',
           '''bool TeamDbnoEnabled() {
    std::scoped_lock lock{team_mutex};
    const auto& lobby = team_gate.Lobby();
    if (!team_switch || !lobby || !lobby->has_team()) {
        return true; // standalone/legacy mode, preserve existing port behavior
    }
    const bbcoop::Team& team = lobby->team();
    return !team.has_dbno_enabled() || team.dbno_enabled();
}

std::string TeamLobbyMember() {
''','world rule read')
    s=once(s, 'void TeamLobbyRequest(bbcoop::TeamRequest::Action action, const std::string& id) {',
           '''void TeamSetDbno(bool enabled) {
    bbcoop::Envelope envelope;
    bbcoop::TeamRequest& request = *envelope.mutable_team_request();
    request.set_action(bbcoop::TeamRequest::SET_DBNO);
    request.set_dbno_enabled(enabled);
    QueueLobby(std::move(envelope)); // trusted shadNet link authenticates requester
}

void TeamLobbyRequest(bbcoop::TeamRequest::Action action, const std::string& id) {''',
           'world send toggle')
    return s

def patch_game_death(s):
    # Always install the existing DBNO hooks on native port; their operational state
    # is decided each game tick from the server's authoritative team rule.
    s=once(s, 'void TickPartyDeath() {\n    if (!party_death_hook_installed) {',
           '''void TickPartyDeath() {
    // Server-authoritative host option. The server refuses changes after Start,
    // so two members cannot disagree while one is down.
    if (!TeamDbnoEnabled()) {
        party_death_data.store(0, std::memory_order_relaxed);
        party_death_armed.store(false, std::memory_order_relaxed);
        party_death_down.store(false, std::memory_order_relaxed);
        PostVitalsWithoutPartyDeath();
        SetPartyPanel({});
        return;
    }
    if (!party_death_hook_installed) {''', 'real game tick')
    return s

def patch_abi_header(s):
    s=once(s, '    bbcoop_lobby_world worlds[BBCOOP_LOBBY_WORLDS];\n} bbcoop_lobby;',
           '    bbcoop_lobby_world worlds[BBCOOP_LOBBY_WORLDS];\n'
           '    int dbno_enabled; // from team state; default ON for legacy teams\n} bbcoop_lobby;',
           'game bridge lobby')
    s=once(s,'void bbcoop_lobby_request(int action, const char *id);',
           'void bbcoop_lobby_request(int action, const char *id);\n'
           'void bbcoop_team_set_dbno(int enabled); // forwards a host request over the co-op stream',
           'game bridge API')
    return s

def patch_bridge(s):
    s=once(s, '        lobby->started = team.started();',
           '        lobby->started = team.started();\n'
           '        lobby->dbno_enabled = !team.has_dbno_enabled() || team.dbno_enabled();',
           'bridge state')
    s=once(s, 'extern "C" void bbcoop_lobby_request(int action, const char* id) {',
           '''extern "C" void bbcoop_team_set_dbno(int enabled) {
    Core::Bloodborne::Coop::TeamSetDbno(enabled != 0);
}

extern "C" void bbcoop_lobby_request(int action, const char* id) {''','bridge request')
    return s

def patch_overlay(s):
    anchor='    // Title and the team\'s state.\n    ImGui::PushFont(MenuArt::Font(), 40.0f);'
    snippet='''    // Seamless Hunt: DBNO is an in-game team rule, not a desktop launcher toggle.
    // This Button is in Team's existing gamepad/mouse focus system.
    if (lobby.in_team) {
        ImGui::PushFont(MenuArt::Font(), 18.0f);
        const std::string dbno_text = lobby.dbno_enabled
            ? T("DBNO: On", "Возрождение: вкл")
            : T("DBNO: Off", "Возрождение: выкл");
        if (Button(draw, "sh-dbno", dbno_text.c_str(),
                   ImVec2(x1 - S(240.0f), win.y + S(24.0f)),
                   ImVec2(S(225.0f), S(40.0f)),
                   lobby.leader && !lobby.started)) {
            bbcoop_team_set_dbno(!lobby.dbno_enabled);
        }
        ImGui::PopFont();
    }

    // Title and the team's state.
    ImGui::PushFont(MenuArt::Font(), 40.0f);'''
    return once(s,anchor,snippet,'real in-game DBNO toggle')

PATCHES={
    'server/coop/coop.proto':patch_proto,
    'server/coop/team_lobby.cpp':patch_server,
    'emulator/src/core/bloodborne_re_internal.h':patch_client_header,
    'emulator/src/core/bloodborne_server_world.cpp':patch_client_world,
    'emulator/src/core/bloodborne_party_death.cpp':patch_game_death,
    'bbport/gpu/bbcoop.h':patch_abi_header,
    'bbport/gpu/bbcoop/coop.cpp':patch_bridge,
    'bbport/gpu/shim/bbport_overlay.cpp':patch_overlay,
}

# Reject applying the same transformation twice even when an old anchor is kept
# (e.g. a function signature to which a new function was prepended).
PATCH_MARKERS={
    'server/coop/coop.proto':'        SET_DBNO = 12;',
    'server/coop/team_lobby.cpp':'DBNO is locked after the hunt starts',
    'emulator/src/core/bloodborne_re_internal.h':'void TeamSetDbno(bool enabled);',
    'emulator/src/core/bloodborne_server_world.cpp':'request.set_dbno_enabled(enabled);',
    'emulator/src/core/bloodborne_party_death.cpp':'if (!TeamDbnoEnabled())',
    'bbport/gpu/bbcoop.h':'void bbcoop_team_set_dbno(int enabled);',
    'bbport/gpu/bbcoop/coop.cpp':'lobby->dbno_enabled = !team.has_dbno_enabled()',
    'bbport/gpu/shim/bbport_overlay.cpp':'"sh-dbno"',
}
assert set(PATCHES)==set(PATCH_MARKERS)
for rel, original_change in list(PATCHES.items()):
    def guarded(source, change=original_change, token=PATCH_MARKERS[rel]):
        if token in source:
            raise ValueError(f'Already patched: {token}')
        return change(source)
    PATCHES[rel]=guarded

def patch_tree(checkout: pathlib.Path, output: pathlib.Path, require_pin=True):
    if require_pin:
        revision=subprocess.check_output(['git','-C',str(checkout),'rev-parse','HEAD'],text=True).strip()
        if revision!=PIN:
            raise RuntimeError(f'Requires upstream {PIN}; got {revision}')
    if checkout.resolve()==output.resolve() or checkout.resolve() in output.resolve().parents:
        raise ValueError('Refusing to modify or create output inside original source tree')
    results={}
    # Atomic semantics: validate ALL files/anchors before output is changed.
    for rel,change in PATCHES.items():
        original=checkout/rel
        if not original.is_file():raise FileNotFoundError(original)
        results[rel]=change(original.read_text(encoding='utf-8'))
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f'Destination must be empty: {output}')
    output.mkdir(parents=True,exist_ok=True)
    for rel,source in results.items():
        destination=output/rel
        destination.parent.mkdir(parents=True,exist_ok=True)
        destination.write_text(source,encoding='utf-8')
    return results

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--checkout',type=pathlib.Path,required=True)
    p.add_argument('--out',type=pathlib.Path,required=True)
    p.add_argument('--allow-synthetic-tests',action='store_true',help=argparse.SUPPRESS)
    args=p.parse_args()
    try:
        result=patch_tree(args.checkout,args.out,not args.allow_synthetic_tests)
    except (OSError,ValueError,RuntimeError,subprocess.CalledProcessError) as e:
        print(f'PATCH FAILED: {e}',file=sys.stderr)
        raise SystemExit(1)
    print(f'PATCH SUCCESS: {len(result)} pinned native client + shadNet source files; no original modified')
    print('NEXT: build both Qt shadNet and Windows native BBPort from patched source, then test')
if __name__=='__main__':main()
