import tempfile, unittest
from pathlib import Path
from patch_native_dbno import PATCHES, once, patch_tree

# Small source fragments copied from the pinned upstream to check safe,
# deterministic replacements. These do NOT substitute for compiling game/Qt.
FIXTURES={
'server/coop/coop.proto': '''    PROTOCOL_CURRENT = 7;
        FORGET_WORLD = 11;\n    }\n    string world = 6;\n}\n\nmessage LobbyPlayer {\n    string party = 7;\n}\n\nmessage TeamInvite {\n''',
'server/coop/team_lobby.cpp':'''    switch (request.action()) {\n    case Action::CREATE: {\n        team.set_leader(member);\n        bbcoop::TeamMember& m = *team.add_members();\n''',
'emulator/src/core/bloodborne_re_internal.h':'''void TeamLobbyRequest(bbcoop::TeamRequest::Action action, const std::string& id);\n''',
'emulator/src/core/bloodborne_server_world.cpp':'''std::string TeamLobbyMember() {\nvoid TeamLobbyRequest(bbcoop::TeamRequest::Action action, const std::string& id) {\n''',
'emulator/src/core/bloodborne_party_death.cpp':'''void TickPartyDeath() {\n    if (!party_death_hook_installed) {\n''',
'bbport/gpu/bbcoop.h':'''    bbcoop_lobby_world worlds[BBCOOP_LOBBY_WORLDS];\n} bbcoop_lobby;\nvoid bbcoop_lobby_request(int action, const char *id);\n''',
'bbport/gpu/bbcoop/coop.cpp':'''        lobby->started = team.started();\nextern "C" void bbcoop_lobby_request(int action, const char* id) {\n''',
'bbport/gpu/shim/bbport_overlay.cpp':'''    // Title and the team's state.\n    ImGui::PushFont(MenuArt::Font(), 40.0f);\n''',
}
class NativePatchTests(unittest.TestCase):
    def test_each_patch_and_feature(self):
        expectations={
            'server/coop/coop.proto':'optional bool dbno_enabled = 8;',
            'server/coop/team_lobby.cpp':'DBNO is locked after the hunt starts',
            'emulator/src/core/bloodborne_re_internal.h':'TeamDbnoEnabled()',
            'emulator/src/core/bloodborne_server_world.cpp':'request.set_dbno_enabled(enabled);',
            'emulator/src/core/bloodborne_party_death.cpp':'if (!TeamDbnoEnabled())',
            'bbport/gpu/bbcoop.h':'void bbcoop_team_set_dbno(int enabled);',
            'bbport/gpu/bbcoop/coop.cpp':'lobby->dbno_enabled = !team.has_dbno_enabled()',
            'bbport/gpu/shim/bbport_overlay.cpp':'"sh-dbno"',
        }
        self.assertEqual(set(FIXTURES),set(PATCHES))
        for key, patch in PATCHES.items():
            with self.subTest(file=key):
                original=FIXTURES[key]
                transformed=patch(original)
                self.assertIn(expectations[key],transformed)
                self.assertNotEqual(original,transformed)
                # Fail-closed on already-patched source.
                with self.assertRaises(ValueError): patch(transformed)
    def test_atomic_output_and_no_inplace(self):
        with tempfile.TemporaryDirectory() as temp:
            src=Path(temp)/'in';out=Path(temp)/'out';src.mkdir()
            for path,text in FIXTURES.items():
                source=src/path;source.parent.mkdir(parents=True,exist_ok=True)
                source.write_text(text,encoding='utf-8')
            patch_tree(src,out,require_pin=False)
            for path,original in FIXTURES.items():
                self.assertEqual((src/path).read_text(),original)
                self.assertNotEqual((out/path).read_text(),original)
            with self.assertRaises(FileExistsError):patch_tree(src,out,require_pin=False)
            (src/'server/coop/coop.proto').write_text('not pinned')
            other=Path(temp)/'bad'
            with self.assertRaises(ValueError):patch_tree(src,other,require_pin=False)
            self.assertFalse(other.exists())
    def test_reject_duplicate_anchor(self):
        with self.assertRaises(ValueError):once('abcabc','abc','z','dupe')
        with self.assertRaises(ValueError):once('def','abc','z','missing')

if __name__=='__main__':unittest.main()
